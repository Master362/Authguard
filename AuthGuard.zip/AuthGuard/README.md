# AuthGuard — autenticación y seguridad para Paper 1.21.4

Plugin de autenticación para servidores **Paper 1.21.4** (Java 21, Gradle). Registro/login con
**Argon2id**, almacenamiento en **SQLite**, protección anti fuerza bruta y bloqueo total de
jugadores no autenticados.

> ⚠️ **Estado de verificación (léelo antes de usarlo en producción).**
> Este proyecto se escribió y revisó en un entorno **sin acceso a Maven/Paper**, por lo que
> **no se ha compilado contra la API real de Paper ni se ha probado en un servidor**.
> Lo que sí se verificó está detallado en [Verificación realizada](#verificación-realizada).
> Compila tú el proyecto (`./gradlew build`) y prueba en un servidor de pruebas antes de
> ponerlo en producción. Si hay algún error de compilación, es muy probable que sea una
> firma de la API de Paper y sea rápido de corregir.

## Funciones

| Área | Detalle |
|---|---|
| Comandos de jugador | `/register <clave> <repetir>` (`/reg`), `/login <clave>` (`/l`), `/logout`, `/changepassword <actual> <nueva>` (`/cp`) |
| Hash | Argon2id (BouncyCastle), sal aleatoria por contraseña, formato PHC, comparación en tiempo constante, re-hash automático si cambias los parámetros |
| Política de contraseñas | Longitud mín/máx, minúscula/mayúscula/número/símbolo, no contener el nombre, lista de contraseñas comunes |
| Anti fuerza bruta | Cooldown entre intentos, bloqueo por cuenta, bloqueo por IP (suma de todas las cuentas), expulsión al bloquear, rechazo de conexiones desde IP bloqueada |
| Sesiones | Reconexión sin clave durante N minutos, solo desde la misma IP (configurable), en memoria |
| Timeout | Expulsa si no te autenticas a tiempo; recordatorios periódicos |
| Suplantación | Nombre ↔ UUID vinculados; se rechaza el mismo nombre con otras mayúsculas o con otro UUID; se rechaza duplicar un jugador ya autenticado; validación del formato del nombre |
| Protección | Bloquea movimiento, chat (y oculta el chat), comandos (y su autocompletado), inventario, soltar/recoger, daño recibido y causado, interacción, bloques, cubos, carteles, libros, teletransporte, hambre, objetivo de mobs |
| Logs | Filtro Log4j que oculta `/login`, `/register`, etc. del log del servidor |
| Admin | `/authadmin` con permisos por subcomando |
| Persistencia | SQLite (WAL), consultas parametrizadas, **todas** las operaciones en un hilo propio; el hashing en otro pool |

## Comandos de administración y permisos

| Subcomando | Permiso | Descripción |
|---|---|---|
| `/authadmin reload` | `authguard.admin.reload` | Recarga `config.yml` y `messages.yml`. Si hay error, se conserva lo anterior |
| `/authadmin stats` | `authguard.admin.stats` | Cuentas, bloqueos activos, eventos 24 h, IPs con más fallos |
| `/authadmin info <jugador>` | `authguard.admin.info` | Datos de la cuenta (incluye IPs) |
| `/authadmin unregister <jugador>` | `authguard.admin.unregister` | Elimina la cuenta y expulsa al jugador |
| `/authadmin setpassword <jugador> <clave>` | `authguard.admin.setpassword` | Fija una contraseña (cierra su sesión) |
| `/authadmin temppass <jugador>` | `authguard.admin.temppass` | Genera contraseña temporal aleatoria; el jugador **debe** cambiarla al entrar |
| `/authadmin unlock <jugador\|IP>` | `authguard.admin.unlock` | Quita bloqueos |
| `/authadmin forcelogout <jugador>` | `authguard.admin.forcelogout` | Cierra la sesión de un jugador conectado |

`authguard.admin` (por defecto `op`) concede todos. `authguard.use` (por defecto todos) permite los comandos de jugador.
Recomendación: ejecuta `setpassword` y `temppass` **desde la consola**.

## Recuperación de contraseñas: limitaciones

- **Las contraseñas no se pueden recuperar**: solo se guarda un hash irreversible. Ni tú ni el plugin podéis verla.
- No hay recuperación por correo: el plugin no pide ni guarda emails. La recuperación es **administrativa**:
  `temppass` (recomendado) o `unregister`.
- **La seguridad de la recuperación depende de que verifiques la identidad del jugador fuera del juego.**
  Quien convenza a un admin de resetear una cuenta, la controla. Define un proceso (p. ej. Discord verificado).
- Con `temppass`, la clave temporal la ve el admin y puede quedar en el historial de su chat o del cliente.
  Úsalo desde consola cuando puedas. La clave temporal obliga a cambiarla y el jugador queda restringido hasta hacerlo.
- `unregister` permite que **cualquiera** que entre con ese nombre se registre primero (en servidores `online-mode=false`).
  Úsalo solo cuando puedas hacer que el dueño real se registre enseguida.

## Limitaciones de seguridad conocidas

- **`online-mode=false`**: la identidad del jugador solo se protege con la contraseña. Un atacante puede intentar entrar con el
  nombre de otro y provocar bloqueos temporales a la cuenta (denegación de servicio acotada). Es el compromiso habitual de la
  fuerza bruta por cuenta. Reduce el impacto bajando `lockout-seconds`.
- **Proxy (Velocity/BungeeCord)**: asegúrate de que los servidores backend **no son accesibles directamente** y de usar el reenvío seguro
  de IP/UUID (modern forwarding con secreto en Velocity). Si no, la IP y el UUID podrían falsearse.
- El filtro de logs depende del formato del mensaje del servidor ("issued server command"). Comprueba tras instalar que
  `/login` ya no aparece en `logs/latest.log`.
- Las contraseñas viajan en un comando de chat: el servidor las ve en claro mientras llegan (como en cualquier plugin de este tipo). Usa HTTPS/VPN/hosting de confianza.
- No usar `/reload` del servidor; reinicia. Si se recarga, los jugadores conectados quedan sin autenticar hasta usar `/login`.
- NPC de otros plugins (p. ej. Citizens) son entidades `Player` no registradas: se tratan como "no autenticados" y se les bloquea daño/interacción.
- Las sesiones están solo en memoria (se pierden al reiniciar). La IP se guarda en claro en la base de datos (auditoría); ajusta `statistics.retention-days` según tu política de privacidad.
- Condiciones de carrera menores: el límite de cuentas por IP se comprueba antes de insertar, sin transacción.

## Requisitos

- **Java 21** (JDK, no solo JRE)
- Servidor **Paper 1.21.4**
- Internet en el **primer arranque** del servidor (Paper descarga `sqlite-jdbc` y `bcprov` desde Maven Central, ver `libraries` en `plugin.yml`)

## 1. Instalar Java 21

- **Windows**: abre PowerShell y ejecuta `winget install EclipseAdoptium.Temurin.21.JDK`. Cierra y abre la terminal.
- **macOS**: `brew install --cask temurin@21`
- **Ubuntu/Debian**: `sudo apt update && sudo apt install openjdk-21-jdk`
- Comprueba: `java -version` y `javac -version` deben mostrar 21.

## 2. Abrir el proyecto en VS Code

1. Instala [VS Code](https://code.visualstudio.com/).
2. Instala las extensiones **Extension Pack for Java** (`vscjava.vscode-java-pack`) y **Gradle for Java** (`vscjava.vscode-gradle`).
3. Descomprime el `.zip`. En VS Code: **Archivo → Abrir carpeta…** y elige la carpeta `AuthGuard`.
4. Espera a que termine de importar el proyecto Gradle (barra inferior). Si pide elegir JDK, elige el 21.

## 3. Compilar

Desde la terminal integrada de VS Code (`Ctrl+ñ` o *Terminal → Nueva terminal*) en la carpeta del proyecto:

```bash
# Linux / macOS (si hace falta: chmod +x gradlew)
./gradlew build

# Windows (PowerShell o CMD)
gradlew.bat build
```

La primera vez descarga Gradle 8.12 y las dependencias (necesita Internet). Resultado:

```
build/libs/AuthGuard-1.0.0.jar
```

Solo pruebas: `./gradlew test`. Informe en `build/reports/tests/test/index.html`.

## 4. Instalar en el servidor

1. Detén el servidor Paper 1.21.4.
2. Copia `build/libs/AuthGuard-1.0.0.jar` a la carpeta `plugins/` del servidor.
3. Inicia el servidor (con Internet la primera vez). Debe aparecer `AuthGuard 1.0.0 activado.`
4. Se crea `plugins/AuthGuard/` con `config.yml`, `messages.yml` y `accounts.db`.
5. Edita la configuración si quieres y aplica con `/authadmin reload`.

## 5. Prueba recomendada (antes de producción)

1. Entra: solo deberías poder escribir `/register` o `/login`; no moverte, chatear, abrir inventario ni recibir daño.
2. `/register Clave1234 Clave1234` → autenticado. Sal y entra: sesión automática (si está activada). Comprueba `/logout`.
3. Falla el login 5 veces: te expulsa y queda bloqueado. `/authadmin unlock <jugador>` lo libera.
4. Comprueba que `logs/latest.log` **no** contiene la clave de `/login`.
5. Prueba `/authadmin temppass` y que el jugador queda obligado a `/changepassword`.

## Estructura

```
src/main/java/dev/authguard/
  AuthGuardPlugin.java        arranque, recarga segura
  auth/                       AuthService (flujos), PlayerStateRegistry, SessionManager
  security/                   Argon2idHasher, PasswordPolicy, AttemptTracker, CommandLogFilter
  storage/                    Database (hilo propio), AccountRepository, Account, EventType
  config/                     Settings (validada e inmutable), Messages (MiniMessage)
  listener/                   ConnectionListener (pre-login/join/quit), ProtectionListener
  command/                    PlayerCommands, AdminCommand
src/main/resources/           plugin.yml, config.yml, messages.yml
src/test/java/                pruebas JUnit 5
```

## Verificación realizada

Hecho en el entorno de desarrollo (sin acceso a los repositorios de Paper/Maven):

- ✅ Clases sin dependencias externas (`PasswordPolicy`, `AttemptTracker`, `SessionManager`, `Argon2Params`, capa `storage`) **compiladas con `javac` 21** y 33 comprobaciones de su lógica ejecutadas con éxito.
- ✅ **SQL** extraído del código y ejecutado contra SQLite real: unicidad por UUID y por nombre (sin distinguir mayúsculas), `INSERT OR IGNORE`, actualizaciones, purga y una cadena de inyección SQL guardada de forma literal.
- ✅ `plugin.yml`, `config.yml`, `messages.yml` son YAML válido; cada clave de mensaje usada en el código existe en `messages.yml`.
- ✅ Todo el código y los tests **compilan con `javac -Xlint:all` contra stubs escritos a mano** de la API (comprueba tipos, genéricos y lógica interna de mi código).

**No verificado:**

- ❌ Compilación contra `paper-api 1.21.4` real (las firmas de los stubs vienen de mi conocimiento de la API, no de la API).
- ❌ Compilación/ejecución contra BouncyCastle y `sqlite-jdbc` reales → `Argon2idHasherTest` y `AccountRepositoryTest` **no se han ejecutado**.
- ❌ Ejecución en un servidor real: filtro de logs, carga de `libraries`, comportamiento de eventos, concurrencia.
