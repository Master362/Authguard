package dev.authguard.auth;

import static dev.authguard.config.Messages.ph;

import java.security.SecureRandom;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.CompletionException;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.logging.Level;

import org.bukkit.Bukkit;
import org.bukkit.entity.Player;

import dev.authguard.AuthGuardPlugin;
import dev.authguard.config.Messages;
import dev.authguard.config.Settings;
import dev.authguard.security.Argon2idHasher;
import dev.authguard.security.AttemptTracker;
import dev.authguard.security.PasswordPolicy;
import dev.authguard.storage.Account;
import dev.authguard.storage.AccountRepository;
import dev.authguard.storage.EventType;

/**
 * Flujos de autenticación: registro, login, logout y cambio de contraseña.
 * Todo método público se llama desde el hilo principal. El hashing y la base de datos
 * corren en hilos propios; los resultados vuelven al hilo principal antes de tocar jugadores.
 */
public final class AuthService {

    private static final String TEMP_ALPHABET = "ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnpqrstuvwxyz23456789";

    private final AuthGuardPlugin plugin;
    private final AccountRepository repository;
    private final PlayerStateRegistry states;
    private final SessionManager sessions = new SessionManager(System::currentTimeMillis);
    private final AttemptTracker tracker;
    private final Argon2idHasher hasher;
    private final ExecutorService hashPool;
    private final Set<UUID> busy = ConcurrentHashMap.newKeySet();
    private final SecureRandom random = new SecureRandom();

    public AuthService(AuthGuardPlugin plugin, AccountRepository repository, PlayerStateRegistry states,
                       Settings settings) {
        this.plugin = plugin;
        this.repository = repository;
        this.states = states;
        this.tracker = new AttemptTracker(settings.attempts(), System::currentTimeMillis);
        this.hasher = new Argon2idHasher(settings.argon2());
        // Pocos hilos a propósito: Argon2 usa mucha memoria y un atacante no debe poder agotarla.
        this.hashPool = Executors.newFixedThreadPool(2, r -> {
            Thread t = new Thread(r, "AuthGuard-Hash");
            t.setDaemon(true);
            return t;
        });
    }

    public void applySettings(Settings settings) {
        tracker.configure(settings.attempts());
        hasher.configure(settings.argon2());
    }

    public AttemptTracker tracker() {
        return tracker;
    }

    public SessionManager sessions() {
        return sessions;
    }

    // ------------------------------------------------------------------ utilidades

    private Messages m() {
        return plugin.messages();
    }

    private Settings cfg() {
        return plugin.settings();
    }

    private void sync(Runnable task) {
        if (plugin.isEnabled()) {
            Bukkit.getScheduler().runTask(plugin, task);
        }
    }

    private static Throwable unwrap(Throwable t) {
        return (t instanceof CompletionException && t.getCause() != null) ? t.getCause() : t;
    }

    private void logError(String what, Throwable t) {
        plugin.getLogger().log(Level.SEVERE, what, unwrap(t));
    }

    /** Registra un evento de auditoría sin bloquear (los fallos solo se anotan en el log). */
    public void audit(String type, String username, String ip) {
        repository.logEvent(type, username, ip, System.currentTimeMillis())
                .exceptionally(t -> {
                    logError("No se pudo guardar un evento de auditoría", t);
                    return null;
                });
    }

    public CompletableFuture<String> hashAsync(String password) {
        return CompletableFuture.supplyAsync(() -> hasher.hash(password), hashPool);
    }

    /** Genera una contraseña temporal aleatoria (sin caracteres ambiguos). */
    public String generateTemporaryPassword() {
        StringBuilder sb = new StringBuilder(14);
        for (int i = 0; i < 14; i++) {
            sb.append(TEMP_ALPHABET.charAt(random.nextInt(TEMP_ALPHABET.length())));
        }
        return sb.toString();
    }

    private void sendViolations(Player player, List<PasswordPolicy.Violation> violations) {
        PasswordPolicy policy = cfg().policy();
        m().send(player, "password.invalid-header");
        for (PasswordPolicy.Violation v : violations) {
            m().send(player, "password." + v.key(), ph("min", policy.minLength()), ph("max", policy.maxLength()));
        }
    }

    private void sendWait(Player player, AttemptTracker.Decision decision) {
        long seconds = Math.max(1, (decision.waitMillis() + 999) / 1000);
        if (decision.status() == AttemptTracker.Status.LOCKED) {
            m().send(player, "login.locked", ph("seconds", seconds));
        } else {
            m().send(player, "login.cooldown", ph("seconds", seconds));
        }
    }

    private void handleFailure(Player player, AttemptTracker.FailureResult failure, String wrongKey) {
        if (failure.lockedNow()) {
            audit(EventType.LOCKOUT, player.getName(), PlayerStateRegistry.ip(player));
            long seconds = cfg().attempts().lockoutMillis() / 1000;
            if (cfg().kickOnLockout()) {
                player.kick(m().component("kick.locked", ph("seconds", seconds)));
            } else {
                m().send(player, "login.locked", ph("seconds", seconds));
            }
        } else {
            m().send(player, wrongKey, ph("remaining", failure.remaining()));
        }
    }

    // ------------------------------------------------------------------ ciclo de vida

    public void onJoin(Player player) {
        UUID id = player.getUniqueId();
        String ip = PlayerStateRegistry.ip(player);
        states.track(player);
        if (player.isInsideVehicle()) {
            player.leaveVehicle();
        }
        repository.findByUuid(id).whenComplete((account, error) -> sync(() -> {
            if (!player.isOnline()) {
                return;
            }
            if (error != null) {
                logError("Error consultando la cuenta de " + player.getName(), error);
                player.kick(m().component("kick.internal-error"));
                return;
            }
            if (states.isAuthenticated(id)) {
                return;
            }
            if (account.isEmpty()) {
                states.setHasAccount(id, false);
                m().send(player, "prompt.register");
                return;
            }
            states.setHasAccount(id, true);
            if (cfg().sessionsEnabled() && sessions.consume(id, ip, cfg().sessionBindIp())) {
                completeAuth(player, account.get(), true);
            } else {
                m().send(player, "prompt.login");
            }
        }));
    }

    public void onQuit(Player player) {
        UUID id = player.getUniqueId();
        if (!states.isTracked(player)) {
            return; // salida de una conexión antigua ya reemplazada: no tocar el estado de la nueva
        }
        if (states.isAuthenticated(id) && cfg().sessionsEnabled()) {
            sessions.create(id, PlayerStateRegistry.ip(player), cfg().sessionDurationMillis());
        }
        states.untrack(player);
        busy.remove(id);
    }

    private void completeAuth(Player player, Account account, boolean viaSession) {
        String ip = PlayerStateRegistry.ip(player);
        repository.updateLogin(account.uuid(), ip, System.currentTimeMillis())
                .exceptionally(t -> {
                    logError("No se pudo actualizar el último acceso", t);
                    return null;
                });
        audit(viaSession ? EventType.SESSION_LOGIN : EventType.LOGIN_OK, player.getName(), ip);
        if (account.mustChange()) {
            states.setMustChange(player);
            m().send(player, "login.must-change");
            return;
        }
        states.setAuthenticated(player);
        m().send(player, viaSession ? "login.session" : "login.success");
    }

    // ------------------------------------------------------------------ registro

    private enum RegisterResult { OK, EXISTS, IP_LIMIT }

    private record RegisterOutcome(RegisterResult result, Account account) { }

    public void register(Player player, String password, String confirm) {
        UUID id = player.getUniqueId();
        if (states.status(id) != PlayerStateRegistry.Status.UNAUTHENTICATED) {
            m().send(player, "common.already-authenticated");
            return;
        }
        if (!password.equals(confirm)) {
            m().send(player, "register.mismatch");
            return;
        }
        List<PasswordPolicy.Violation> violations = cfg().policy().validate(password, player.getName());
        if (!violations.isEmpty()) {
            sendViolations(player, violations);
            return;
        }
        if (!busy.add(id)) {
            m().send(player, "common.busy");
            return;
        }
        Settings s = cfg();
        String ip = PlayerStateRegistry.ip(player);
        String name = player.getName();

        repository.countByRegisterIp(ip)
                .thenCompose(count -> {
                    if (s.maxAccountsPerIp() > 0 && count >= s.maxAccountsPerIp()) {
                        return CompletableFuture.completedFuture(new RegisterOutcome(RegisterResult.IP_LIMIT, null));
                    }
                    return hashAsync(password).thenCompose(hash -> {
                        long now = System.currentTimeMillis();
                        Account account = new Account(id, name, hash, false, now, ip, now, ip, now);
                        return repository.insert(account).thenApply(inserted -> new RegisterOutcome(
                                inserted ? RegisterResult.OK : RegisterResult.EXISTS, inserted ? account : null));
                    });
                })
                .whenComplete((outcome, error) -> sync(() -> {
                    busy.remove(id);
                    if (!player.isOnline()) {
                        return;
                    }
                    if (error != null) {
                        logError("Error en el registro de " + name, error);
                        m().send(player, "common.internal-error");
                        return;
                    }
                    switch (outcome.result()) {
                        case OK -> {
                            states.setHasAccount(id, true);
                            audit(EventType.REGISTER, name, ip);
                            completeAuthAfterRegister(player, outcome.account());
                        }
                        case EXISTS -> m().send(player, "register.already-registered");
                        case IP_LIMIT -> m().send(player, "register.ip-limit", ph("max", s.maxAccountsPerIp()));
                    }
                }));
    }

    private void completeAuthAfterRegister(Player player, Account account) {
        states.setAuthenticated(player);
        m().send(player, "register.success");
    }

    // ------------------------------------------------------------------ login

    private enum LoginKind { NO_ACCOUNT, OK, BAD }

    private record LoginOutcome(LoginKind kind, Account account, String newHash) { }

    public void login(Player player, String password) {
        UUID id = player.getUniqueId();
        if (states.status(id) != PlayerStateRegistry.Status.UNAUTHENTICATED) {
            m().send(player, "common.already-authenticated");
            return;
        }
        if (!busy.add(id)) {
            m().send(player, "common.busy");
            return;
        }
        String ip = PlayerStateRegistry.ip(player);
        AttemptTracker.Decision decision = tracker.tryAcquire(id.toString(), ip);
        if (!decision.allowed()) {
            busy.remove(id);
            sendWait(player, decision);
            return;
        }

        repository.findByUuid(id)
                .thenApplyAsync(found -> {
                    if (found.isEmpty()) {
                        return new LoginOutcome(LoginKind.NO_ACCOUNT, null, null);
                    }
                    Account account = found.get();
                    if (!hasher.verify(password, account.passwordHash())) {
                        return new LoginOutcome(LoginKind.BAD, null, null);
                    }
                    String upgraded = hasher.needsRehash(account.passwordHash()) ? hasher.hash(password) : null;
                    return new LoginOutcome(LoginKind.OK, account, upgraded);
                }, hashPool)
                .whenComplete((outcome, error) -> sync(() -> {
                    busy.remove(id);
                    if (!player.isOnline()) {
                        return;
                    }
                    if (error != null) {
                        logError("Error en el login de " + player.getName(), error);
                        m().send(player, "common.internal-error");
                        return;
                    }
                    switch (outcome.kind()) {
                        case NO_ACCOUNT -> m().send(player, "login.not-registered");
                        case OK -> {
                            tracker.recordSuccess(id.toString());
                            if (outcome.newHash() != null) {
                                repository.updateHash(id, outcome.newHash()).exceptionally(t -> {
                                    logError("No se pudo actualizar el hash", t);
                                    return null;
                                });
                            }
                            completeAuth(player, outcome.account(), false);
                        }
                        case BAD -> {
                            AttemptTracker.FailureResult failure = tracker.recordFailure(id.toString(), ip);
                            audit(EventType.LOGIN_FAIL, player.getName(), ip);
                            handleFailure(player, failure, "login.wrong-password");
                        }
                    }
                }));
    }

    // ------------------------------------------------------------------ logout

    public void logout(Player player) {
        UUID id = player.getUniqueId();
        if (states.status(id) == PlayerStateRegistry.Status.UNAUTHENTICATED) {
            m().send(player, "logout.not-logged-in");
            return;
        }
        sessions.invalidate(id);
        states.setUnauthenticated(player);
        states.setHasAccount(id, true);
        m().send(player, "logout.success");
        m().send(player, "prompt.login");
    }

    /** Cierra la sesión de un jugador por orden administrativa (o tras cambiar su contraseña). */
    public void forceLogout(UUID id) {
        sessions.invalidate(id);
        Player player = Bukkit.getPlayer(id);
        if (player != null && states.status(id) != PlayerStateRegistry.Status.UNAUTHENTICATED) {
            states.setUnauthenticated(player);
            states.setHasAccount(id, true);
            m().send(player, "admin.you-were-logged-out");
        }
    }

    // ------------------------------------------------------------------ cambio de contraseña

    private enum ChangeKind { OK, BAD_OLD, NO_ACCOUNT }

    private record ChangeStep(ChangeKind kind, String newHash) { }

    public void changePassword(Player player, String oldPassword, String newPassword) {
        UUID id = player.getUniqueId();
        if (states.status(id) == PlayerStateRegistry.Status.UNAUTHENTICATED) {
            m().send(player, "common.not-authenticated");
            return;
        }
        if (oldPassword.equals(newPassword)) {
            m().send(player, "changepassword.same");
            return;
        }
        List<PasswordPolicy.Violation> violations = cfg().policy().validate(newPassword, player.getName());
        if (!violations.isEmpty()) {
            sendViolations(player, violations);
            return;
        }
        if (!busy.add(id)) {
            m().send(player, "common.busy");
            return;
        }
        String ip = PlayerStateRegistry.ip(player);
        AttemptTracker.Decision decision = tracker.tryAcquire(id.toString(), ip);
        if (!decision.allowed()) {
            busy.remove(id);
            sendWait(player, decision);
            return;
        }

        repository.findByUuid(id)
                .thenApplyAsync(found -> {
                    if (found.isEmpty()) {
                        return new ChangeStep(ChangeKind.NO_ACCOUNT, null);
                    }
                    if (!hasher.verify(oldPassword, found.get().passwordHash())) {
                        return new ChangeStep(ChangeKind.BAD_OLD, null);
                    }
                    return new ChangeStep(ChangeKind.OK, hasher.hash(newPassword));
                }, hashPool)
                .thenCompose(step -> {
                    if (step.kind() != ChangeKind.OK) {
                        return CompletableFuture.completedFuture(step);
                    }
                    return repository.updatePassword(id, step.newHash(), false, System.currentTimeMillis())
                            .thenApply(updated -> updated ? step : new ChangeStep(ChangeKind.NO_ACCOUNT, null));
                })
                .whenComplete((step, error) -> sync(() -> {
                    busy.remove(id);
                    if (!player.isOnline()) {
                        return;
                    }
                    if (error != null) {
                        logError("Error cambiando la contraseña de " + player.getName(), error);
                        m().send(player, "common.internal-error");
                        return;
                    }
                    switch (step.kind()) {
                        case OK -> {
                            tracker.recordSuccess(id.toString());
                            audit(EventType.PASSWORD_CHANGED, player.getName(), ip);
                            states.setAuthenticated(player);
                            m().send(player, "changepassword.success");
                        }
                        case BAD_OLD -> {
                            AttemptTracker.FailureResult failure = tracker.recordFailure(id.toString(), ip);
                            audit(EventType.PASSWORD_CHANGE_FAIL, player.getName(), ip);
                            handleFailure(player, failure, "changepassword.wrong-old");
                        }
                        case NO_ACCOUNT -> m().send(player, "login.not-registered");
                    }
                }));
    }

    // ------------------------------------------------------------------ mantenimiento

    /** Tareas periódicas asíncronas: limpieza de memoria y purga de eventos antiguos. */
    public void startMaintenance() {
        Bukkit.getScheduler().runTaskTimerAsynchronously(plugin, () -> {
            tracker.purge();
            sessions.purgeExpired();
        }, 20L * 60, 20L * 60 * 5);

        Bukkit.getScheduler().runTaskTimerAsynchronously(plugin, () -> {
            long cutoff = System.currentTimeMillis() - cfg().retentionDays() * 86_400_000L;
            repository.purgeEventsBefore(cutoff).exceptionally(t -> {
                logError("No se pudieron purgar los eventos antiguos", t);
                return 0;
            });
        }, 20L * 30, 20L * 60 * 60 * 6);
    }

    public void shutdown() {
        hashPool.shutdown();
    }

    /** Resumen de estado actual para /authadmin stats. */
    public Map<String, Integer> liveCounters() {
        return Map.of(
                "locks", tracker.activeLockCount(),
                "sessions", sessions.size(),
                "authenticated", states.authenticatedCount());
    }

    public PlayerStateRegistry.Status stateOf(UUID id) {
        return states.status(id);
    }
}
