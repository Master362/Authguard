package dev.authguard.auth;

import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitTask;

import dev.authguard.AuthGuardPlugin;
import dev.authguard.config.Messages;
import dev.authguard.storage.EventType;

/**
 * Estado de autenticación de cada jugador conectado. Regla de seguridad clave: cualquier
 * jugador que NO esté registrado aquí como AUTHENTICATED se considera restringido
 * (fail-closed), también los que ya estaban conectados cuando se cargó el plugin.
 */
public final class PlayerStateRegistry {

    public enum Status { UNAUTHENTICATED, MUST_CHANGE_PASSWORD, AUTHENTICATED }

    private static final class State {
        final Player owner;
        volatile Status status = Status.UNAUTHENTICATED;
        volatile Boolean hasAccount;
        BukkitTask timeout;
        BukkitTask reminder;

        State(Player owner) {
            this.owner = owner;
        }
    }

    private final AuthGuardPlugin plugin;
    private final Map<UUID, State> states = new ConcurrentHashMap<>();
    private final Map<String, UUID> onlineNames = new ConcurrentHashMap<>();

    public PlayerStateRegistry(AuthGuardPlugin plugin) {
        this.plugin = plugin;
    }

    /** IP del jugador como texto ("unknown" si no está disponible). */
    public static String ip(Player player) {
        InetSocketAddress address = player.getAddress();
        if (address == null) {
            return "unknown";
        }
        InetAddress inet = address.getAddress();
        return inet != null ? inet.getHostAddress() : address.getHostString();
    }

    public void track(Player player) {
        State previous = states.put(player.getUniqueId(), new State(player));
        if (previous != null) {
            cancelTimers(previous);
        }
        onlineNames.put(player.getName().toLowerCase(Locale.ROOT), player.getUniqueId());
        startTimers(player, states.get(player.getUniqueId()));
    }

    /**
     * True si este objeto Player es el dueño del estado actual. Evita que el evento de salida de una
     * conexión antigua (misma UUID, expulsada al reconectar) borre el estado de la conexión nueva.
     */
    public boolean isTracked(Player player) {
        State state = states.get(player.getUniqueId());
        return state != null && state.owner == player;
    }

    public void untrack(Player player) {
        UUID id = player.getUniqueId();
        State state = states.get(id);
        if (state == null || state.owner != player) {
            return;
        }
        if (states.remove(id, state)) {
            cancelTimers(state);
            onlineNames.remove(player.getName().toLowerCase(Locale.ROOT), id);
        }
    }

    public Status status(UUID id) {
        State state = states.get(id);
        return state == null ? Status.UNAUTHENTICATED : state.status;
    }

    public boolean isAuthenticated(UUID id) {
        return status(id) == Status.AUTHENTICATED;
    }

    /** True si el jugador debe estar limitado (no autenticado, o debe cambiar la contraseña). */
    public boolean isRestricted(UUID id) {
        return !isAuthenticated(id);
    }

    /** Usado en el pre-login (hilo asíncrono): ¿hay un jugador autenticado con ese nombre conectado? */
    public boolean isNameOnlineAuthenticated(String lowerName) {
        UUID id = onlineNames.get(lowerName);
        return id != null && isAuthenticated(id);
    }

    public int authenticatedCount() {
        int count = 0;
        for (State s : states.values()) {
            if (s.status == Status.AUTHENTICATED) {
                count++;
            }
        }
        return count;
    }

    public void setHasAccount(UUID id, boolean value) {
        State state = states.get(id);
        if (state != null) {
            state.hasAccount = value;
        }
    }

    public void setAuthenticated(Player player) {
        State state = states.get(player.getUniqueId());
        if (state == null) {
            return;
        }
        state.status = Status.AUTHENTICATED;
        cancelTimers(state);
    }

    public void setMustChange(Player player) {
        State state = states.get(player.getUniqueId());
        if (state == null) {
            return;
        }
        state.status = Status.MUST_CHANGE_PASSWORD;
        restartTimers(player, state);
    }

    public void setUnauthenticated(Player player) {
        State state = states.get(player.getUniqueId());
        if (state == null) {
            return;
        }
        state.status = Status.UNAUTHENTICATED;
        restartTimers(player, state);
    }

    public void shutdown() {
        for (State state : states.values()) {
            cancelTimers(state);
        }
        states.clear();
        onlineNames.clear();
    }

    private void restartTimers(Player player, State state) {
        cancelTimers(state);
        startTimers(player, state);
    }

    private static void cancelTimers(State state) {
        if (state.timeout != null) {
            state.timeout.cancel();
            state.timeout = null;
        }
        if (state.reminder != null) {
            state.reminder.cancel();
            state.reminder = null;
        }
    }

    private void startTimers(Player player, State state) {
        if (state == null) {
            return;
        }
        UUID id = player.getUniqueId();
        long timeoutTicks = plugin.settings().timeoutSeconds() * 20L;
        long reminderTicks = plugin.settings().reminderSeconds() * 20L;

        state.timeout = Bukkit.getScheduler().runTaskLater(plugin, () -> {
            if (states.get(id) == state && state.status != Status.AUTHENTICATED && player.isOnline()) {
                plugin.service().audit(EventType.KICK_TIMEOUT, player.getName(), ip(player));
                player.kick(plugin.messages().component("kick.timeout"));
            }
        }, timeoutTicks);

        state.reminder = Bukkit.getScheduler().runTaskTimer(plugin, () -> {
            if (states.get(id) != state || !player.isOnline()) {
                return;
            }
            Messages messages = plugin.messages();
            if (state.status == Status.MUST_CHANGE_PASSWORD) {
                messages.send(player, "prompt.must-change");
            } else if (state.status == Status.UNAUTHENTICATED && state.hasAccount != null) {
                messages.send(player, state.hasAccount ? "prompt.login" : "prompt.register");
            }
        }, 20L, reminderTicks);
    }
}
