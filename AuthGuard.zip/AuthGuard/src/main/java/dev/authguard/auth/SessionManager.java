package dev.authguard.auth;

import java.util.Map;
import java.util.Objects;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.LongSupplier;

/**
 * Sesiones en memoria: permiten reconectar sin escribir la contraseña durante un tiempo,
 * siempre desde la misma IP (configurable). Se pierden al reiniciar el servidor a propósito.
 */
public final class SessionManager {

    private record Session(String ip, long expiresAt) { }

    private final Map<UUID, Session> sessions = new ConcurrentHashMap<>();
    private final LongSupplier clock;

    public SessionManager(LongSupplier clock) {
        this.clock = clock;
    }

    public void create(UUID id, String ip, long durationMillis) {
        sessions.put(id, new Session(ip, clock.getAsLong() + durationMillis));
    }

    /**
     * Consume la sesión si es válida. Un intento desde otra IP NO destruye la sesión
     * legítima (evita que un atacante la invalide).
     */
    public boolean consume(UUID id, String ip, boolean bindToIp) {
        Session session = sessions.get(id);
        if (session == null) {
            return false;
        }
        if (clock.getAsLong() >= session.expiresAt()) {
            sessions.remove(id, session);
            return false;
        }
        if (bindToIp && !Objects.equals(session.ip(), ip)) {
            return false;
        }
        return sessions.remove(id, session);
    }

    public void invalidate(UUID id) {
        sessions.remove(id);
    }

    public void purgeExpired() {
        long now = clock.getAsLong();
        sessions.values().removeIf(s -> now >= s.expiresAt());
    }

    public int size() {
        return sessions.size();
    }
}
