package dev.authguard;

import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.Reader;
import java.io.UncheckedIOException;
import java.nio.charset.StandardCharsets;
import java.util.List;
import java.util.Objects;
import java.util.logging.Level;

import org.bukkit.Bukkit;
import org.bukkit.command.PluginCommand;
import org.bukkit.configuration.InvalidConfigurationException;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;

import dev.authguard.auth.AuthService;
import dev.authguard.auth.PlayerStateRegistry;
import dev.authguard.command.AdminCommand;
import dev.authguard.command.PlayerCommands;
import dev.authguard.config.Messages;
import dev.authguard.config.Settings;
import dev.authguard.listener.ConnectionListener;
import dev.authguard.listener.ProtectionListener;
import dev.authguard.security.CommandLogFilter;
import dev.authguard.storage.AccountRepository;
import dev.authguard.storage.Database;

public final class AuthGuardPlugin extends JavaPlugin {

    private volatile Settings settings;
    private volatile Messages messages;
    private Database database;
    private AccountRepository repository;
    private PlayerStateRegistry states;
    private AuthService service;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        if (!new File(getDataFolder(), "messages.yml").exists()) {
            saveResource("messages.yml", false);
        }

        try {
            this.settings = loadSettings();
            this.messages = loadMessages();
        } catch (RuntimeException e) {
            getLogger().log(Level.SEVERE, "Configuración inválida, el plugin se desactiva: " + e.getMessage());
            getServer().getPluginManager().disablePlugin(this);
            return;
        }

        try {
            this.database = new Database(getDataFolder().toPath().resolve(settings.databaseFile()), getLogger());
            this.repository = new AccountRepository(database);
            repository.initSchema().join();
        } catch (Exception e) {
            getLogger().log(Level.SEVERE, "No se pudo abrir la base de datos, el plugin se desactiva", e);
            getServer().getPluginManager().disablePlugin(this);
            return;
        }

        this.states = new PlayerStateRegistry(this);
        this.service = new AuthService(this, repository, states, settings);

        getServer().getPluginManager().registerEvents(new ConnectionListener(this, service, states, repository), this);
        getServer().getPluginManager().registerEvents(new ProtectionListener(this, states), this);

        PlayerCommands playerCommands = new PlayerCommands(this, service);
        for (String name : List.of("register", "login", "logout", "changepassword")) {
            PluginCommand command = Objects.requireNonNull(getCommand(name), "Falta el comando en plugin.yml: " + name);
            command.setExecutor(playerCommands);
            command.setTabCompleter(playerCommands);
        }
        AdminCommand adminCommand = new AdminCommand(this, service, repository);
        PluginCommand admin = Objects.requireNonNull(getCommand("authadmin"), "Falta authadmin en plugin.yml");
        admin.setExecutor(adminCommand);
        admin.setTabCompleter(adminCommand);

        if (settings.logFilter()) {
            CommandLogFilter.install(getLogger());
        }
        service.startMaintenance();

        // Jugadores ya conectados (p. ej. tras /reload): quedan restringidos hasta autenticarse.
        for (Player player : Bukkit.getOnlinePlayers()) {
            service.onJoin(player);
        }

        if (Bukkit.getOnlineMode()) {
            getLogger().info("El servidor está en online-mode=true: AuthGuard sigue activo, pero la protección "
                    + "frente a suplantación de nombres la aporta principalmente Mojang.");
        } else {
            getLogger().warning("online-mode=false: la identidad solo se protege con las contraseñas de AuthGuard. "
                    + "Si usas proxy (Velocity/BungeeCord), asegúrate de que el servidor no sea accesible directamente.");
        }
        getLogger().info("AuthGuard " + getPluginMeta().getVersion() + " activado.");
    }

    @Override
    public void onDisable() {
        CommandLogFilter.deactivate();
        if (states != null) {
            states.shutdown();
        }
        if (service != null) {
            service.shutdown();
        }
        if (database != null) {
            database.close();
        }
    }

    /** Recarga config.yml y messages.yml. Si algo es inválido se lanza excepción y no se cambia nada. */
    public synchronized void reloadSettings() {
        Settings newSettings = loadSettings();
        Messages newMessages = loadMessages();
        if (!newSettings.databaseFile().equals(settings.databaseFile())) {
            getLogger().warning("database.file cambió: requiere reiniciar el servidor para aplicarse.");
        }
        this.settings = newSettings;
        this.messages = newMessages;
        service.applySettings(newSettings);
        reloadConfig();
    }

    private Settings loadSettings() {
        File file = new File(getDataFolder(), "config.yml");
        YamlConfiguration yaml = new YamlConfiguration();
        try {
            yaml.load(file);
        } catch (IOException | InvalidConfigurationException e) {
            throw new IllegalArgumentException("config.yml ilegible o con YAML inválido: " + e.getMessage(), e);
        }
        return Settings.load(yaml);
    }

    private Messages loadMessages() {
        try (Reader defaults = new InputStreamReader(
                Objects.requireNonNull(getResource("messages.yml"), "messages.yml no está en el .jar"),
                StandardCharsets.UTF_8)) {
            return Messages.load(new File(getDataFolder(), "messages.yml"), defaults);
        } catch (IOException e) {
            throw new UncheckedIOException(e);
        }
    }

    public Settings settings() {
        return settings;
    }

    public Messages messages() {
        return messages;
    }

    public AuthService service() {
        return service;
    }
}
