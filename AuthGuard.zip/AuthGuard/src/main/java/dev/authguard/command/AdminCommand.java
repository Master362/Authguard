package dev.authguard.command;

import static dev.authguard.config.Messages.ph;

import java.time.Instant;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.CompletableFuture;
import java.util.function.Consumer;
import java.util.logging.Level;

import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;

import dev.authguard.AuthGuardPlugin;
import dev.authguard.auth.AuthService;
import dev.authguard.auth.PlayerStateRegistry;
import dev.authguard.config.Messages;
import dev.authguard.security.PasswordPolicy;
import dev.authguard.storage.Account;
import dev.authguard.storage.AccountRepository;
import dev.authguard.storage.EventType;

/** /authadmin con permisos granulares: authguard.admin.&lt;subcomando&gt;. */
public final class AdminCommand implements CommandExecutor, TabCompleter {

    private static final List<String> SUBS = List.of(
            "reload", "stats", "info", "unregister", "setpassword", "temppass", "unlock", "forcelogout");
    private static final List<String> SUBS_WITH_PLAYER = List.of(
            "info", "unregister", "setpassword", "temppass", "unlock", "forcelogout");
    private static final DateTimeFormatter DATE =
            DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss").withZone(ZoneId.systemDefault());

    private final AuthGuardPlugin plugin;
    private final AuthService service;
    private final AccountRepository repository;

    public AdminCommand(AuthGuardPlugin plugin, AuthService service, AccountRepository repository) {
        this.plugin = plugin;
        this.service = service;
        this.repository = repository;
    }

    private Messages m() {
        return plugin.messages();
    }

    private void sync(Runnable task) {
        if (plugin.isEnabled()) {
            Bukkit.getScheduler().runTask(plugin, task);
        }
    }

    private void fail(CommandSender sender, Throwable error) {
        plugin.getLogger().log(Level.SEVERE, "Error en /authadmin", error);
        m().send(sender, "common.internal-error");
    }

    private void audit(CommandSender sender, String action, String target) {
        plugin.getLogger().info("[admin] " + sender.getName() + " ejecutó '" + action + "' sobre " + target);
        service.audit(EventType.ADMIN, target, null);
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (args.length == 0) {
            help(sender);
            return true;
        }
        String sub = args[0].toLowerCase(Locale.ROOT);
        if (!SUBS.contains(sub)) {
            help(sender);
            return true;
        }
        if (!sender.hasPermission("authguard.admin." + sub)) {
            m().send(sender, "common.no-permission");
            return true;
        }
        switch (sub) {
            case "reload" -> reload(sender);
            case "stats" -> stats(sender);
            case "info" -> withAccount(sender, args, 2, "info", account -> info(sender, account));
            case "unregister" -> withAccount(sender, args, 2, "unregister", account -> unregister(sender, account));
            case "setpassword" -> withAccount(sender, args, 3, "setpassword",
                    account -> setPassword(sender, account, args[2]));
            case "temppass" -> withAccount(sender, args, 2, "temppass", account -> tempPass(sender, account));
            case "unlock" -> unlock(sender, args);
            case "forcelogout" -> forceLogout(sender, args);
            default -> help(sender);
        }
        return true;
    }

    private void help(CommandSender sender) {
        m().sendPlain(sender, "admin.help-header");
        for (String sub : SUBS) {
            if (sender.hasPermission("authguard.admin." + sub)) {
                m().sendPlain(sender, "admin.help." + sub);
            }
        }
    }

    /** Valida los argumentos, busca la cuenta de forma asíncrona y ejecuta la acción en el hilo principal. */
    private void withAccount(CommandSender sender, String[] args, int expectedArgs, String sub,
                             Consumer<Account> action) {
        if (args.length != expectedArgs) {
            m().send(sender, "admin.usage." + sub);
            return;
        }
        String name = args[1];
        repository.findByName(name.toLowerCase(Locale.ROOT)).whenComplete((found, error) -> sync(() -> {
            if (error != null) {
                fail(sender, error);
            } else if (found.isEmpty()) {
                m().send(sender, "admin.no-account", ph("name", name));
            } else {
                action.accept(found.get());
            }
        }));
    }

    private void reload(CommandSender sender) {
        try {
            plugin.reloadSettings();
            m().send(sender, "admin.reload-ok");
            plugin.getLogger().info("Configuración recargada por " + sender.getName());
        } catch (RuntimeException e) {
            plugin.getLogger().log(Level.WARNING, "Recarga fallida; se mantiene la configuración anterior", e);
            m().send(sender, "admin.reload-failed", ph("error", String.valueOf(e.getMessage())));
        }
    }

    private void stats(CommandSender sender) {
        long since = System.currentTimeMillis() - 86_400_000L;
        CompletableFuture<Long> accounts = repository.countAccounts();
        CompletableFuture<Map<String, Long>> events = repository.countEventsSince(since);
        CompletableFuture<List<AccountRepository.IpCount>> topIps = repository.topFailingIps(since, 5);
        CompletableFuture.allOf(accounts, events, topIps).whenComplete((ignored, error) -> sync(() -> {
            if (error != null) {
                fail(sender, error);
                return;
            }
            Map<String, Integer> live = service.liveCounters();
            m().sendPlain(sender, "admin.stats.header");
            m().sendPlain(sender, "admin.stats.accounts", ph("count", accounts.join()));
            m().sendPlain(sender, "admin.stats.live",
                    ph("authenticated", live.get("authenticated")),
                    ph("locks", live.get("locks")),
                    ph("sessions", live.get("sessions")));
            m().sendPlain(sender, "admin.stats.events-header");
            if (events.join().isEmpty()) {
                m().sendPlain(sender, "admin.stats.no-events");
            }
            events.join().forEach((type, count) ->
                    m().sendPlain(sender, "admin.stats.event", ph("type", type), ph("count", count)));
            m().sendPlain(sender, "admin.stats.ips-header");
            if (topIps.join().isEmpty()) {
                m().sendPlain(sender, "admin.stats.no-ips");
            }
            for (AccountRepository.IpCount row : topIps.join()) {
                m().sendPlain(sender, "admin.stats.ip", ph("ip", row.ip()), ph("count", row.count()));
            }
        }));
    }

    private void info(CommandSender sender, Account account) {
        Player online = Bukkit.getPlayer(account.uuid());
        String status = online == null ? "desconectado"
                : switch (service.stateOf(account.uuid())) {
                    case AUTHENTICATED -> "autenticado";
                    case MUST_CHANGE_PASSWORD -> "debe cambiar la contraseña";
                    case UNAUTHENTICATED -> "sin autenticar";
                };
        m().sendPlain(sender, "admin.info",
                ph("name", account.username()),
                ph("uuid", account.uuid()),
                ph("status", status),
                ph("registered", formatTime(account.registeredAt())),
                ph("register_ip", String.valueOf(account.registerIp())),
                ph("last_login", formatTime(account.lastLoginAt())),
                ph("last_ip", String.valueOf(account.lastLoginIp())),
                ph("pw_changed", formatTime(account.passwordChangedAt())),
                ph("must_change", account.mustChange() ? "sí" : "no"));
    }

    private static String formatTime(long millis) {
        return millis <= 0 ? "nunca" : DATE.format(Instant.ofEpochMilli(millis));
    }

    private void unregister(CommandSender sender, Account account) {
        repository.delete(account.uuid()).whenComplete((deleted, error) -> sync(() -> {
            if (error != null) {
                fail(sender, error);
                return;
            }
            service.sessions().invalidate(account.uuid());
            Player online = Bukkit.getPlayer(account.uuid());
            if (online != null) {
                online.kick(m().component("kick.account-removed"));
            }
            // El evento de salida puede crear una sesión; se invalida de nuevo en el siguiente tick.
            Bukkit.getScheduler().runTask(plugin, () -> service.sessions().invalidate(account.uuid()));
            audit(sender, "unregister", account.username());
            m().send(sender, "admin.unregister-ok", ph("name", account.username()));
        }));
    }

    private void setPassword(CommandSender sender, Account account, String password) {
        List<PasswordPolicy.Violation> violations = plugin.settings().policy().validate(password, account.username());
        if (!violations.isEmpty()) {
            m().send(sender, "password.invalid-header");
            for (PasswordPolicy.Violation v : violations) {
                m().send(sender, "password." + v.key(),
                        ph("min", plugin.settings().policy().minLength()),
                        ph("max", plugin.settings().policy().maxLength()));
            }
            return;
        }
        service.hashAsync(password)
                .thenCompose(hash -> repository.updatePassword(account.uuid(), hash, false, System.currentTimeMillis()))
                .whenComplete((updated, error) -> sync(() -> {
                    if (error != null) {
                        fail(sender, error);
                        return;
                    }
                    service.forceLogout(account.uuid());
                    audit(sender, "setpassword", account.username());
                    m().send(sender, "admin.setpassword-ok", ph("name", account.username()));
                }));
    }

    private void tempPass(CommandSender sender, Account account) {
        String temporary = service.generateTemporaryPassword();
        service.hashAsync(temporary)
                .thenCompose(hash -> repository.updatePassword(account.uuid(), hash, true, System.currentTimeMillis()))
                .whenComplete((updated, error) -> sync(() -> {
                    if (error != null) {
                        fail(sender, error);
                        return;
                    }
                    service.forceLogout(account.uuid());
                    audit(sender, "temppass", account.username());
                    m().send(sender, "admin.temppass-ok", ph("name", account.username()), ph("password", temporary));
                    if (sender instanceof Player) {
                        m().send(sender, "admin.temppass-warning");
                    }
                }));
    }

    private void unlock(CommandSender sender, String[] args) {
        if (args.length != 2) {
            m().send(sender, "admin.usage.unlock");
            return;
        }
        String target = args[1];
        if (target.contains(".") || target.contains(":")) {
            boolean changed = service.tracker().unlock(target);
            audit(sender, "unlock", target);
            m().send(sender, changed ? "admin.unlock-ok" : "admin.unlock-nothing", ph("target", target));
            return;
        }
        withAccount(sender, args, 2, "unlock", account -> {
            boolean changed = service.tracker().unlock(account.uuid().toString());
            audit(sender, "unlock", account.username());
            m().send(sender, changed ? "admin.unlock-ok" : "admin.unlock-nothing", ph("target", account.username()));
        });
    }

    private void forceLogout(CommandSender sender, String[] args) {
        if (args.length != 2) {
            m().send(sender, "admin.usage.forcelogout");
            return;
        }
        Player target = Bukkit.getPlayerExact(args[1]);
        if (target == null) {
            m().send(sender, "admin.not-online", ph("name", args[1]));
            return;
        }
        service.forceLogout(target.getUniqueId());
        audit(sender, "forcelogout", target.getName());
        m().send(sender, "admin.forcelogout-ok", ph("name", target.getName()));
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        List<String> result = new ArrayList<>();
        if (args.length == 1) {
            for (String sub : SUBS) {
                if (sub.startsWith(args[0].toLowerCase(Locale.ROOT)) && sender.hasPermission("authguard.admin." + sub)) {
                    result.add(sub);
                }
            }
        } else if (args.length == 2 && SUBS_WITH_PLAYER.contains(args[0].toLowerCase(Locale.ROOT))
                && sender.hasPermission("authguard.admin." + args[0].toLowerCase(Locale.ROOT))) {
            for (Player p : Bukkit.getOnlinePlayers()) {
                if (p.getName().toLowerCase(Locale.ROOT).startsWith(args[1].toLowerCase(Locale.ROOT))) {
                    result.add(p.getName());
                }
            }
        }
        return result;
    }
}
