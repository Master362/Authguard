package dev.authguard.command;

import java.util.List;
import java.util.Locale;

import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;

import dev.authguard.AuthGuardPlugin;
import dev.authguard.auth.AuthService;

/** /register, /login, /logout y /changepassword. */
public final class PlayerCommands implements CommandExecutor, TabCompleter {

    private final AuthGuardPlugin plugin;
    private final AuthService service;

    public PlayerCommands(AuthGuardPlugin plugin, AuthService service) {
        this.plugin = plugin;
        this.service = service;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player player)) {
            plugin.messages().send(sender, "common.players-only");
            return true;
        }
        switch (command.getName().toLowerCase(Locale.ROOT)) {
            case "register" -> {
                if (args.length != 2) {
                    plugin.messages().send(player, "usage.register");
                } else {
                    service.register(player, args[0], args[1]);
                }
            }
            case "login" -> {
                if (args.length != 1) {
                    plugin.messages().send(player, "usage.login");
                } else {
                    service.login(player, args[0]);
                }
            }
            case "logout" -> service.logout(player);
            case "changepassword" -> {
                if (args.length != 2) {
                    plugin.messages().send(player, "usage.changepassword");
                } else {
                    service.changePassword(player, args[0], args[1]);
                }
            }
            default -> plugin.messages().send(player, "common.internal-error");
        }
        return true;
    }

    /** Nunca se sugiere nada: evita que contraseñas parciales o nombres se filtren al autocompletar. */
    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        return List.of();
    }
}
