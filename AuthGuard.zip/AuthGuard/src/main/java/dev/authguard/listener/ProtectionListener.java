package dev.authguard.listener;

import java.util.Locale;
import java.util.Set;

import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.entity.Projectile;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.block.SignChangeEvent;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.EntityPickupItemEvent;
import org.bukkit.event.entity.EntityTargetEvent;
import org.bukkit.event.entity.FoodLevelChangeEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.inventory.InventoryOpenEvent;
import org.bukkit.event.player.PlayerArmorStandManipulateEvent;
import org.bukkit.event.player.PlayerBucketEmptyEvent;
import org.bukkit.event.player.PlayerBucketFillEvent;
import org.bukkit.event.player.PlayerCommandPreprocessEvent;
import org.bukkit.event.player.PlayerCommandSendEvent;
import org.bukkit.event.player.PlayerDropItemEvent;
import org.bukkit.event.player.PlayerEditBookEvent;
import org.bukkit.event.player.PlayerInteractEntityEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerItemConsumeEvent;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.event.player.PlayerSwapHandItemsEvent;
import org.bukkit.event.player.PlayerTeleportEvent;

import dev.authguard.AuthGuardPlugin;
import dev.authguard.auth.PlayerStateRegistry;
import io.papermc.paper.event.player.AsyncChatEvent;

/**
 * Bloquea las acciones de jugadores no autenticados. Se usa prioridad HIGHEST para tener la
 * última palabra antes de MONITOR. Los jugadores desconocidos para el plugin se tratan como
 * no autenticados (fail-closed).
 */
public final class ProtectionListener implements Listener {

    /** Con contraseña temporal solo se permite cambiarla (o salir de la sesión). */
    private static final Set<String> MUST_CHANGE_ALLOWED = Set.of("changepassword", "changepass", "cp", "logout");

    private final AuthGuardPlugin plugin;
    private final PlayerStateRegistry states;

    public ProtectionListener(AuthGuardPlugin plugin, PlayerStateRegistry states) {
        this.plugin = plugin;
        this.states = states;
    }

    private boolean restricted(Entity entity) {
        return entity instanceof Player player && states.isRestricted(player.getUniqueId());
    }

    private Set<String> allowedCommandsFor(Player player) {
        if (states.status(player.getUniqueId()) == PlayerStateRegistry.Status.MUST_CHANGE_PASSWORD) {
            return MUST_CHANGE_ALLOWED;
        }
        return plugin.settings().allowedCommands();
    }

    // ---------------------------------------------------------------- movimiento y teletransporte

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onMove(PlayerMoveEvent event) {
        if (!restricted(event.getPlayer()) || event.getTo() == null) {
            return;
        }
        var from = event.getFrom();
        var to = event.getTo();
        // Se permite girar la cabeza y caer, pero no desplazarse ni subir.
        if (from.getX() != to.getX() || from.getZ() != to.getZ() || to.getY() > from.getY()) {
            event.setCancelled(true);
        }
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onTeleport(PlayerTeleportEvent event) {
        if (!restricted(event.getPlayer())) {
            return;
        }
        if (plugin.settings().allowPluginTeleports() && event.getCause() == PlayerTeleportEvent.TeleportCause.PLUGIN) {
            return;
        }
        event.setCancelled(true);
    }

    // ---------------------------------------------------------------- chat y comandos

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onChat(AsyncChatEvent event) {
        Player player = event.getPlayer();
        if (restricted(player)) {
            event.setCancelled(true);
            plugin.messages().send(player, "protect.chat-blocked");
            return;
        }
        if (plugin.settings().hideChat()) {
            event.viewers().removeIf(audience -> audience instanceof Player p && states.isRestricted(p.getUniqueId()));
        }
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onCommand(PlayerCommandPreprocessEvent event) {
        Player player = event.getPlayer();
        if (!restricted(player)) {
            return;
        }
        String message = event.getMessage().strip();
        if (message.startsWith("/")) {
            message = message.substring(1);
        }
        String label = message.split("\\s+", 2)[0].toLowerCase(Locale.ROOT);
        if (label.startsWith("authguard:")) {
            label = label.substring("authguard:".length());
        }
        if (!allowedCommandsFor(player).contains(label)) {
            event.setCancelled(true);
            plugin.messages().send(player, "protect.command-blocked");
        }
    }

    /** Oculta la lista de comandos disponibles (y el autocompletado) a jugadores restringidos. */
    @EventHandler(priority = EventPriority.HIGHEST)
    public void onCommandSend(PlayerCommandSendEvent event) {
        if (restricted(event.getPlayer())) {
            event.getCommands().retainAll(allowedCommandsFor(event.getPlayer()));
        }
    }

    // ---------------------------------------------------------------- interacción con el mundo

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onInteract(PlayerInteractEvent event) {
        if (restricted(event.getPlayer())) {
            event.setCancelled(true);
        }
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onInteractEntity(PlayerInteractEntityEvent event) {
        if (restricted(event.getPlayer())) {
            event.setCancelled(true);
        }
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onArmorStand(PlayerArmorStandManipulateEvent event) {
        if (restricted(event.getPlayer())) {
            event.setCancelled(true);
        }
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onBlockBreak(BlockBreakEvent event) {
        if (restricted(event.getPlayer())) {
            event.setCancelled(true);
        }
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onBlockPlace(BlockPlaceEvent event) {
        if (restricted(event.getPlayer())) {
            event.setCancelled(true);
        }
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onSign(SignChangeEvent event) {
        if (restricted(event.getPlayer())) {
            event.setCancelled(true);
        }
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onBucketEmpty(PlayerBucketEmptyEvent event) {
        if (restricted(event.getPlayer())) {
            event.setCancelled(true);
        }
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onBucketFill(PlayerBucketFillEvent event) {
        if (restricted(event.getPlayer())) {
            event.setCancelled(true);
        }
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onBook(PlayerEditBookEvent event) {
        if (restricted(event.getPlayer())) {
            event.setCancelled(true);
        }
    }

    // ---------------------------------------------------------------- inventario

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onInventoryOpen(InventoryOpenEvent event) {
        if (restricted(event.getPlayer())) {
            event.setCancelled(true);
        }
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onInventoryClick(InventoryClickEvent event) {
        if (restricted(event.getWhoClicked())) {
            event.setCancelled(true);
        }
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onInventoryDrag(InventoryDragEvent event) {
        if (restricted(event.getWhoClicked())) {
            event.setCancelled(true);
        }
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onDrop(PlayerDropItemEvent event) {
        if (restricted(event.getPlayer())) {
            event.setCancelled(true);
        }
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onSwapHands(PlayerSwapHandItemsEvent event) {
        if (restricted(event.getPlayer())) {
            event.setCancelled(true);
        }
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onPickup(EntityPickupItemEvent event) {
        if (restricted(event.getEntity())) {
            event.setCancelled(true);
        }
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onConsume(PlayerItemConsumeEvent event) {
        if (restricted(event.getPlayer())) {
            event.setCancelled(true);
        }
    }

    // ---------------------------------------------------------------- combate y estado

    /** Un jugador sin autenticar no recibe daño. */
    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onDamaged(EntityDamageEvent event) {
        if (restricted(event.getEntity())) {
            event.setCancelled(true);
        }
    }

    /** Un jugador sin autenticar tampoco puede dañar a otros (directamente o con proyectiles). */
    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onAttack(EntityDamageByEntityEvent event) {
        Entity damager = event.getDamager();
        if (restricted(damager)) {
            event.setCancelled(true);
            return;
        }
        if (damager instanceof Projectile projectile && projectile.getShooter() instanceof Entity shooter
                && restricted(shooter)) {
            event.setCancelled(true);
        }
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onHunger(FoodLevelChangeEvent event) {
        if (restricted(event.getEntity())) {
            event.setCancelled(true);
        }
    }

    /** Los monstruos no atacan a jugadores sin autenticar. */
    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onTarget(EntityTargetEvent event) {
        if (event.getTarget() != null && restricted(event.getTarget())) {
            event.setCancelled(true);
        }
    }
}
