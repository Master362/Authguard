package dev.authguard.listener;

import java.util.Locale;
import java.util.Optional;
import java.util.concurrent.TimeUnit;
import java.util.logging.Level;

import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.AsyncPlayerPreLoginEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;

import dev.authguard.AuthGuardPlugin;
import dev.authguard.auth.AuthService;
import dev.authguard.auth.PlayerStateRegistry;
import dev.authguard.config.Messages;
import dev.authguard.config.Settings;
import dev.authguard.storage.Account;
import dev.authguard.storage.AccountRepository;
import net.kyori.adventure.text.Component;

import static dev.authguard.config.Messages.ph;

/** Entrada y salida de jugadores, y prevención de suplantación de nombre/UUID. */
public final class ConnectionListener implements Listener {

    private final AuthGuardPlugin plugin;
    private final AuthService service;
    private final PlayerStateRegistry states;
    private final AccountRepository repository;

    public ConnectionListener(AuthGuardPlugin plugin, AuthService service, PlayerStateRegistry states,
                              AccountRepository repository) {
        this.plugin = plugin;
        this.service = service;
        this.states = states;
        this.repository = repository;
    }

    private static void deny(AsyncPlayerPreLoginEvent event, Component reason) {
        event.disallow(AsyncPlayerPreLoginEvent.Result.KICK_OTHER, reason);
    }

    /**
     * Se ejecuta en un hilo asíncrono, por lo que puede esperar a la base de datos.
     * Falla cerrado: si no se puede comprobar la identidad, se deniega la conexión.
     */
    @EventHandler(priority = EventPriority.HIGH)
    public void onPreLogin(AsyncPlayerPreLoginEvent event) {
        if (event.getLoginResult() != AsyncPlayerPreLoginEvent.Result.ALLOWED) {
            return;
        }
        Settings settings = plugin.settings();
        Messages messages = plugin.messages();
        String name = event.getName();
        String lower = name.toLowerCase(Locale.ROOT);
        String ip = event.getAddress().getHostAddress();

        if (!settings.usernamePattern().matcher(name).matches()) {
            deny(event, messages.component("kick.invalid-username"));
            return;
        }

        long ipLock = service.tracker().ipLockRemaining(ip);
        if (ipLock > 0) {
            deny(event, messages.component("kick.ip-locked", ph("seconds", Math.max(1, ipLock / 1000))));
            return;
        }

        // Solo se bloquea el duplicado si el que ya está dentro está autenticado. Si el existente
        // aún no se ha autenticado, el servidor lo expulsa y el dueño real puede entrar.
        if (settings.denyDuplicateLogin() && states.isNameOnlineAuthenticated(lower)) {
            deny(event, messages.component("kick.already-online"));
            return;
        }

        try {
            Optional<Account> existing = repository.findByName(lower).get(5, TimeUnit.SECONDS);
            if (existing.isPresent()) {
                Account account = existing.get();
                // Mismo nombre con otras mayúsculas, o mismo nombre con otro UUID => posible suplantación.
                if (!account.username().equals(name) || !account.uuid().equals(event.getUniqueId())) {
                    plugin.getLogger().warning("Conexión rechazada por posible suplantación: nombre=" + name
                            + " uuid=" + event.getUniqueId() + " ip=" + ip);
                    deny(event, messages.component("kick.identity-mismatch", ph("name", account.username())));
                }
            }
        } catch (Exception e) {
            if (e instanceof InterruptedException) {
                Thread.currentThread().interrupt();
            }
            plugin.getLogger().log(Level.SEVERE, "No se pudo verificar la identidad de " + name, e);
            deny(event, messages.component("kick.internal-error"));
        }
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onJoin(PlayerJoinEvent event) {
        service.onJoin(event.getPlayer());
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onQuit(PlayerQuitEvent event) {
        service.onQuit(event.getPlayer());
    }
}
