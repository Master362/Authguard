package dev.authguard.security;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Set;

/** Política de contraseñas configurable. No depende de Bukkit para poder probarse aislada. */
public record PasswordPolicy(int minLength, int maxLength, boolean requireLower, boolean requireUpper,
                             boolean requireDigit, boolean requireSymbol, boolean denyUsername,
                             boolean denyCommon) {

    public enum Violation {
        TOO_SHORT("too-short"),
        TOO_LONG("too-long"),
        NEEDS_LOWER("needs-lower"),
        NEEDS_UPPER("needs-upper"),
        NEEDS_DIGIT("needs-digit"),
        NEEDS_SYMBOL("needs-symbol"),
        CONTAINS_USERNAME("contains-username"),
        TOO_COMMON("too-common"),
        INVALID_CHARS("invalid-chars");

        private final String key;

        Violation(String key) {
            this.key = key;
        }

        /** Clave usada en messages.yml bajo "password.". */
        public String key() {
            return key;
        }
    }

    /** Lista pequeña de contraseñas triviales; no sustituye a una lista de filtrado externa. */
    private static final Set<String> COMMON = Set.of(
            "password", "123456", "12345678", "123456789", "1234567890", "12345", "qwerty", "qwerty123",
            "qwertyuiop", "abc123", "password1", "password123", "iloveyou", "admin", "admin123", "letmein",
            "welcome", "monkey", "dragon", "111111", "000000", "654321", "987654321", "123123", "12341234",
            "minecraft", "minecraft123", "contrasena", "contraseña", "contrasena123", "1q2w3e4r", "passw0rd",
            "football", "sunshine", "princess", "master", "hello123", "whatever", "trustno1", "changeme",
            "123qwe", "qazwsx", "zaq12wsx", "asdfghjkl", "superman", "batman", "pokemon", "roblox",
            "fortnite", "freefire", "teamo", "holamundo", "hola1234");

    public PasswordPolicy {
        if (minLength < 1 || minLength > 128) {
            throw new IllegalArgumentException("min-length debe estar entre 1 y 128");
        }
        if (maxLength < minLength || maxLength > 128) {
            throw new IllegalArgumentException("max-length debe estar entre min-length y 128");
        }
    }

    public List<Violation> validate(String password, String username) {
        List<Violation> result = new ArrayList<>();
        if (password == null) {
            result.add(Violation.TOO_SHORT);
            return result;
        }
        int length = password.codePointCount(0, password.length());
        if (length < minLength) {
            result.add(Violation.TOO_SHORT);
        }
        if (length > maxLength) {
            result.add(Violation.TOO_LONG);
        }

        boolean lower = false;
        boolean upper = false;
        boolean digit = false;
        boolean symbol = false;
        boolean invalid = false;
        for (int i = 0; i < password.length(); ) {
            int cp = password.codePointAt(i);
            i += Character.charCount(cp);
            if (Character.isISOControl(cp)) {
                invalid = true;
            } else if (Character.isLowerCase(cp)) {
                lower = true;
            } else if (Character.isUpperCase(cp)) {
                upper = true;
            } else if (Character.isDigit(cp)) {
                digit = true;
            } else if (!Character.isLetter(cp)) {
                symbol = true;
            }
        }
        if (invalid) {
            result.add(Violation.INVALID_CHARS);
        }
        if (requireLower && !lower) {
            result.add(Violation.NEEDS_LOWER);
        }
        if (requireUpper && !upper) {
            result.add(Violation.NEEDS_UPPER);
        }
        if (requireDigit && !digit) {
            result.add(Violation.NEEDS_DIGIT);
        }
        if (requireSymbol && !symbol) {
            result.add(Violation.NEEDS_SYMBOL);
        }

        String lowered = password.toLowerCase(Locale.ROOT);
        if (denyUsername && username != null && username.length() >= 3
                && lowered.contains(username.toLowerCase(Locale.ROOT))) {
            result.add(Violation.CONTAINS_USERNAME);
        }
        if (denyCommon && COMMON.contains(lowered)) {
            result.add(Violation.TOO_COMMON);
        }
        return result;
    }
}
