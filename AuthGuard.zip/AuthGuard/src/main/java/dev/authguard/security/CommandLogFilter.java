package dev.authguard.security;

import java.util.regex.Pattern;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.core.LogEvent;
import org.apache.logging.log4j.core.filter.AbstractFilter;

/**
 * Filtro de Log4j2 que descarta las líneas de log donde el servidor registra los comandos
 * ejecutados por jugadores ("X issued server command: /login contraseña"), para que las
 * contraseñas no acaben escritas en latest.log ni en la consola.
 *
 * Es "mejor esfuerzo": depende del formato de ese mensaje en el servidor. Tras instalar el
 * plugin, comprueba en el log que /login ya no aparece.
 */
public final class CommandLogFilter extends AbstractFilter {

    private static final Pattern SENSITIVE = Pattern.compile(
            "issued server command:\\s*/?(?:[a-z0-9_.-]+:)?"
                    + "(login|l|register|reg|changepassword|changepass|cp|authadmin|aadmin)(\\s|$)",
            Pattern.CASE_INSENSITIVE);

    private static volatile boolean active;
    private static boolean installed;

    private CommandLogFilter() {
        super();
    }

    public static synchronized void install(java.util.logging.Logger pluginLog) {
        active = true;
        if (installed) {
            return;
        }
        try {
            org.apache.logging.log4j.core.Logger root =
                    (org.apache.logging.log4j.core.Logger) LogManager.getRootLogger();
            root.addFilter(new CommandLogFilter());
            installed = true;
        } catch (Throwable t) {
            pluginLog.warning("No se pudo instalar el filtro de logs de contraseñas: " + t);
        }
    }

    public static void deactivate() {
        active = false;
    }

    @Override
    public Result filter(LogEvent event) {
        if (!active || event == null || event.getMessage() == null) {
            return Result.NEUTRAL;
        }
        String text = event.getMessage().getFormattedMessage();
        if (text != null && SENSITIVE.matcher(text).find()) {
            return Result.DENY;
        }
        return Result.NEUTRAL;
    }
}
