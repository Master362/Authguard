package dev.authguard.security;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.SecureRandom;
import java.util.Arrays;
import java.util.Base64;

import org.bouncycastle.crypto.generators.Argon2BytesGenerator;
import org.bouncycastle.crypto.params.Argon2Parameters;

/**
 * Hash de contraseñas con Argon2id (BouncyCastle). Formato almacenado, compatible con el
 * formato PHC habitual:
 * <pre>$argon2id$v=19$m=19456,t=2,p=1$&lt;salt base64&gt;$&lt;hash base64&gt;</pre>
 * Cada contraseña usa una sal aleatoria propia; la comparación es en tiempo constante.
 */
public final class Argon2idHasher {

    private static final SecureRandom RANDOM = new SecureRandom();
    private static final Base64.Encoder ENC = Base64.getEncoder().withoutPadding();
    private static final Base64.Decoder DEC = Base64.getDecoder();

    private volatile Argon2Params params;

    public Argon2idHasher(Argon2Params params) {
        this.params = params;
    }

    public void configure(Argon2Params params) {
        this.params = params;
    }

    /** Genera el hash codificado de la contraseña. Operación costosa: no llamar desde el hilo principal. */
    public String hash(String password) {
        Argon2Params p = params;
        byte[] salt = new byte[p.saltBytes()];
        RANDOM.nextBytes(salt);
        byte[] out = derive(password, salt, p.memoryKib(), p.iterations(), p.parallelism(), p.hashBytes());
        return "$argon2id$v=19$m=" + p.memoryKib() + ",t=" + p.iterations() + ",p=" + p.parallelism()
                + "$" + ENC.encodeToString(salt) + "$" + ENC.encodeToString(out);
    }

    /** Verifica una contraseña contra un hash codificado. Devuelve false si el hash es inválido. */
    public boolean verify(String password, String encoded) {
        Parsed parsed = parse(encoded);
        if (parsed == null) {
            return false;
        }
        byte[] actual = derive(password, parsed.salt, parsed.memory, parsed.iterations, parsed.parallelism,
                parsed.hash.length);
        return MessageDigest.isEqual(actual, parsed.hash);
    }

    /** True si el hash usa parámetros distintos de los actuales (hay que re-hashear al próximo login). */
    public boolean needsRehash(String encoded) {
        Parsed parsed = parse(encoded);
        if (parsed == null) {
            return true;
        }
        Argon2Params p = params;
        return parsed.memory != p.memoryKib() || parsed.iterations != p.iterations()
                || parsed.parallelism != p.parallelism() || parsed.hash.length != p.hashBytes()
                || parsed.salt.length != p.saltBytes();
    }

    private static byte[] derive(String password, byte[] salt, int memoryKib, int iterations, int parallelism,
                                 int hashLength) {
        byte[] pw = password.getBytes(StandardCharsets.UTF_8);
        try {
            Argon2Parameters ap = new Argon2Parameters.Builder(Argon2Parameters.ARGON2_id)
                    .withVersion(Argon2Parameters.ARGON2_VERSION_13)
                    .withSalt(salt)
                    .withIterations(iterations)
                    .withMemoryAsKB(memoryKib)
                    .withParallelism(parallelism)
                    .build();
            Argon2BytesGenerator generator = new Argon2BytesGenerator();
            generator.init(ap);
            byte[] out = new byte[hashLength];
            generator.generateBytes(pw, out);
            return out;
        } finally {
            Arrays.fill(pw, (byte) 0);
        }
    }

    private record Parsed(int memory, int iterations, int parallelism, byte[] salt, byte[] hash) { }

    /** Valida estrictamente el formato y acota los parámetros para que una fila manipulada no cause un DoS. */
    private static Parsed parse(String encoded) {
        if (encoded == null) {
            return null;
        }
        try {
            String[] parts = encoded.split("\\$");
            // "", "argon2id", "v=19", "m=..,t=..,p=..", salt, hash
            if (parts.length != 6 || !parts[0].isEmpty() || !parts[1].equals("argon2id") || !parts[2].equals("v=19")) {
                return null;
            }
            int m = 0;
            int t = 0;
            int p = 0;
            for (String kv : parts[3].split(",")) {
                String[] pair = kv.split("=");
                if (pair.length != 2) {
                    return null;
                }
                int value = Integer.parseInt(pair[1]);
                switch (pair[0]) {
                    case "m" -> m = value;
                    case "t" -> t = value;
                    case "p" -> p = value;
                    default -> {
                        return null;
                    }
                }
            }
            if (m < 8 || m > Argon2Params.MAX_MEMORY_KIB || t < 1 || t > 10 || p < 1 || p > 8) {
                return null;
            }
            byte[] salt = DEC.decode(parts[4]);
            byte[] hash = DEC.decode(parts[5]);
            if (salt.length < 8 || salt.length > 64 || hash.length < 16 || hash.length > 64) {
                return null;
            }
            return new Parsed(m, t, p, salt, hash);
        } catch (IllegalArgumentException e) {
            return null;
        }
    }
}
