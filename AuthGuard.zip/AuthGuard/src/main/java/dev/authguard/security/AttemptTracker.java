package dev.authguard.security;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.function.LongSupplier;

/**
 * Limitador de intentos de autenticación (fuerza bruta).
 *
 * <ul>
 *   <li><b>Cooldown</b>: tiempo mínimo entre intentos de una misma cuenta.</li>
 *   <li><b>Bloqueo por cuenta</b>: N fallos dentro de una ventana → bloqueo temporal.</li>
 *   <li><b>Bloqueo por IP</b>: cuenta los fallos de todas las cuentas desde una misma IP.</li>
 * </ul>
 * Es seguro entre hilos (métodos sincronizados) y usa un reloj inyectable para las pruebas.
 */
public final class AttemptTracker {

    public record Config(int maxAttempts, long windowMillis, long lockoutMillis, long cooldownMillis,
                         int ipMaxAttempts, long ipLockoutMillis) {
        public Config {
            if (maxAttempts < 1 || ipMaxAttempts < 1) {
                throw new IllegalArgumentException("los máximos de intentos deben ser >= 1");
            }
            if (windowMillis < 1000 || lockoutMillis < 1000 || ipLockoutMillis < 1000) {
                throw new IllegalArgumentException("ventana y bloqueos deben ser >= 1 segundo");
            }
            if (cooldownMillis < 0) {
                throw new IllegalArgumentException("el cooldown no puede ser negativo");
            }
        }
    }

    public enum Status { ALLOWED, COOLDOWN, LOCKED }

    public record Decision(Status status, long waitMillis) {
        public boolean allowed() {
            return status == Status.ALLOWED;
        }
    }

    public record FailureResult(int attempts, int remaining, boolean lockedNow) { }

    private static final class Bucket {
        int failures;
        long windowStart;
        long lockedUntil;
        long lastAttempt = Long.MIN_VALUE / 2;
    }

    private final LongSupplier clock;
    private volatile Config config;
    private final Map<String, Bucket> accounts = new HashMap<>();
    private final Map<String, Bucket> ips = new HashMap<>();

    public AttemptTracker(Config config, LongSupplier clock) {
        this.config = config;
        this.clock = clock;
    }

    public void configure(Config config) {
        this.config = config;
    }

    /** Comprueba si se permite un intento y, si es así, lo registra para el cooldown. */
    public synchronized Decision tryAcquire(String accountKey, String ip) {
        long now = clock.getAsLong();
        Bucket ipBucket = ips.get(ip);
        if (ipBucket != null && ipBucket.lockedUntil > now) {
            return new Decision(Status.LOCKED, ipBucket.lockedUntil - now);
        }
        Bucket account = accounts.computeIfAbsent(accountKey, k -> new Bucket());
        if (account.lockedUntil > now) {
            return new Decision(Status.LOCKED, account.lockedUntil - now);
        }
        long since = now - account.lastAttempt;
        if (since < config.cooldownMillis()) {
            return new Decision(Status.COOLDOWN, config.cooldownMillis() - since);
        }
        account.lastAttempt = now;
        return new Decision(Status.ALLOWED, 0);
    }

    public synchronized FailureResult recordFailure(String accountKey, String ip) {
        long now = clock.getAsLong();
        Config c = config;
        Bucket account = accounts.computeIfAbsent(accountKey, k -> new Bucket());
        boolean lockedAccount = fail(account, now, c.windowMillis(), c.maxAttempts(), c.lockoutMillis());
        Bucket ipBucket = ips.computeIfAbsent(ip, k -> new Bucket());
        boolean lockedIp = fail(ipBucket, now, c.windowMillis(), c.ipMaxAttempts(), c.ipLockoutMillis());
        int attempts = lockedAccount ? c.maxAttempts() : account.failures;
        return new FailureResult(attempts, Math.max(0, c.maxAttempts() - attempts), lockedAccount || lockedIp);
    }

    private static boolean fail(Bucket bucket, long now, long window, int max, long lockout) {
        if (bucket.failures == 0 || now - bucket.windowStart > window) {
            bucket.failures = 0;
            bucket.windowStart = now;
        }
        bucket.failures++;
        if (bucket.failures >= max) {
            bucket.failures = 0;
            bucket.lockedUntil = now + lockout;
            return true;
        }
        return false;
    }

    /** Un login correcto reinicia los fallos de la cuenta (no los de la IP). */
    public synchronized void recordSuccess(String accountKey) {
        Bucket account = accounts.get(accountKey);
        if (account != null) {
            account.failures = 0;
        }
    }

    /** Milisegundos restantes de bloqueo de una IP (0 si no está bloqueada). */
    public synchronized long ipLockRemaining(String ip) {
        Bucket bucket = ips.get(ip);
        if (bucket == null) {
            return 0;
        }
        return Math.max(0, bucket.lockedUntil - clock.getAsLong());
    }

    /** Desbloquea una cuenta (clave = UUID) o una IP. Devuelve true si había algo que limpiar. */
    public synchronized boolean unlock(String key) {
        boolean changed = reset(accounts.get(key));
        changed |= reset(ips.get(key));
        return changed;
    }

    private boolean reset(Bucket bucket) {
        if (bucket == null) {
            return false;
        }
        boolean had = bucket.failures > 0 || bucket.lockedUntil > clock.getAsLong();
        bucket.failures = 0;
        bucket.lockedUntil = 0;
        return had;
    }

    public synchronized int activeLockCount() {
        long now = clock.getAsLong();
        int count = 0;
        for (Bucket b : accounts.values()) {
            if (b.lockedUntil > now) {
                count++;
            }
        }
        for (Bucket b : ips.values()) {
            if (b.lockedUntil > now) {
                count++;
            }
        }
        return count;
    }

    /** Elimina entradas inactivas para que el mapa no crezca indefinidamente. */
    public synchronized void purge() {
        long now = clock.getAsLong();
        Config c = config;
        purge(accounts, now, c);
        purge(ips, now, c);
    }

    private static void purge(Map<String, Bucket> map, long now, Config c) {
        Iterator<Bucket> it = map.values().iterator();
        while (it.hasNext()) {
            Bucket b = it.next();
            boolean windowDone = b.failures == 0 || now - b.windowStart > c.windowMillis();
            if (b.lockedUntil <= now && windowDone && now - b.lastAttempt > c.cooldownMillis()) {
                it.remove();
            }
        }
    }
}
