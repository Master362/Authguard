package dev.authguard.security;

/**
 * Parámetros de coste de Argon2id. Los valores por defecto siguen la
 * recomendación de OWASP (m=19 MiB, t=2, p=1).
 */
public record Argon2Params(int memoryKib, int iterations, int parallelism, int saltBytes, int hashBytes) {

    public static final int MIN_MEMORY_KIB = 8192;
    public static final int MAX_MEMORY_KIB = 262_144;
    public static final Argon2Params DEFAULT = new Argon2Params(19_456, 2, 1, 16, 32);

    public Argon2Params {
        if (memoryKib < MIN_MEMORY_KIB || memoryKib > MAX_MEMORY_KIB) {
            throw new IllegalArgumentException("memory-kib debe estar entre " + MIN_MEMORY_KIB + " y " + MAX_MEMORY_KIB);
        }
        if (iterations < 1 || iterations > 10) {
            throw new IllegalArgumentException("iterations debe estar entre 1 y 10");
        }
        if (parallelism < 1 || parallelism > 8) {
            throw new IllegalArgumentException("parallelism debe estar entre 1 y 8");
        }
        if (saltBytes < 16 || saltBytes > 64) {
            throw new IllegalArgumentException("salt-bytes debe estar entre 16 y 64");
        }
        if (hashBytes < 16 || hashBytes > 64) {
            throw new IllegalArgumentException("hash-bytes debe estar entre 16 y 64");
        }
    }
}
