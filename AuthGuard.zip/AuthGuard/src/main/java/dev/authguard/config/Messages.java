package dev.authguard.config;

import java.io.File;
import java.io.Reader;
import java.util.HashMap;
import java.util.Map;

import org.bukkit.command.CommandSender;
import org.bukkit.configuration.file.YamlConfiguration;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.minimessage.MiniMessage;
import net.kyori.adventure.text.minimessage.tag.resolver.Placeholder;
import net.kyori.adventure.text.minimessage.tag.resolver.TagResolver;

/**
 * Mensajes personalizables (messages.yml) con formato MiniMessage. Las claves que falten en el
 * archivo del usuario se completan con los valores por defecto incluidos en el .jar.
 * Los datos dinámicos (nombres, números) se insertan como texto plano para evitar inyección de etiquetas.
 */
public final class Messages {

    private static final MiniMessage MM = MiniMessage.miniMessage();

    private final Map<String, String> values;

    private Messages(Map<String, String> values) {
        this.values = values;
    }

    public static Messages load(File userFile, Reader defaults) {
        Map<String, String> map = new HashMap<>();
        YamlConfiguration def = YamlConfiguration.loadConfiguration(defaults);
        for (String key : def.getKeys(true)) {
            if (def.isString(key)) {
                map.put(key, def.getString(key));
            }
        }
        YamlConfiguration user = YamlConfiguration.loadConfiguration(userFile);
        for (String key : user.getKeys(true)) {
            if (user.isString(key)) {
                map.put(key, user.getString(key));
            }
        }
        return new Messages(map);
    }

    /** Marcador de posición de texto plano: &lt;nombre&gt; en el mensaje. */
    public static TagResolver ph(String name, Object value) {
        return Placeholder.unparsed(name, String.valueOf(value));
    }

    /** Componente sin prefijo (para expulsiones y títulos). */
    public Component component(String key, TagResolver... resolvers) {
        return MM.deserialize(raw(key), TagResolver.resolver(resolvers));
    }

    /** Envía un mensaje con prefijo. */
    public void send(CommandSender target, String key, TagResolver... resolvers) {
        target.sendMessage(MM.deserialize(values.getOrDefault("prefix", "") + raw(key), TagResolver.resolver(resolvers)));
    }

    /** Envía un mensaje sin prefijo (listas, estadísticas). */
    public void sendPlain(CommandSender target, String key, TagResolver... resolvers) {
        target.sendMessage(component(key, resolvers));
    }

    private String raw(String key) {
        String value = values.get(key);
        return value != null ? value : "<red>[AuthGuard] Falta el mensaje: " + key;
    }
}
