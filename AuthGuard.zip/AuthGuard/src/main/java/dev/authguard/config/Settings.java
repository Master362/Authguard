package dev.authguard.config;

import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.regex.Pattern;
import java.util.regex.PatternSyntaxException;

import org.bukkit.configuration.file.FileConfiguration;

import dev.authguard.security.Argon2Params;
import dev.authguard.security.AttemptTracker;
import dev.authguard.security.PasswordPolicy;

/**
 * Configuración validada e inmutable. Si algún valor es inválido se lanza
 * IllegalArgumentException y, en una recarga, se conserva la configuración anterior.
 */
public record Settings(
        String databaseFile,
        int timeoutSeconds,
        int reminderSeconds,
        Pattern usernamePattern,
        boolean denyDuplicateLogin,
        Set<String> allowedCommands,
        boolean hideChat,
        boolean allowPluginTeleports,
        PasswordPolicy policy,
        Argon2Params argon2,
        AttemptTracker.Config attempts,
        int maxAccountsPerIp,
        boolean kickOnLockout,
        boolean logFilter,
        boolean sessionsEnabled,
        long sessionDurationMillis,
        boolean sessionBindIp,
        int retentionDays) {

    /** Comandos que siempre deben poder usarse sin autenticar. */
    private static final Set<String> MANDATORY_COMMANDS = Set.of("login", "l", "register", "reg");

    public static Settings load(FileConfiguration c) {
        String dbFile = c.getString("database.file", "accounts.db");
        if (dbFile == null || !dbFile.matches("[A-Za-z0-9_.-]{1,64}") || dbFile.contains("..")) {
            throw new IllegalArgumentException("database.file debe ser un nombre de archivo simple (sin rutas)");
        }

        Pattern pattern;
        try {
            pattern = Pattern.compile(c.getString("authentication.username-pattern", "^[A-Za-z0-9_]{3,16}$"));
        } catch (PatternSyntaxException e) {
            throw new IllegalArgumentException("authentication.username-pattern no es una expresión regular válida");
        }

        Set<String> allowed = new HashSet<>(MANDATORY_COMMANDS);
        List<String> extra = c.getStringList("authentication.extra-allowed-commands");
        for (String cmd : extra) {
            if (cmd != null && !cmd.isBlank()) {
                allowed.add(cmd.trim().toLowerCase(Locale.ROOT).replaceFirst("^/", ""));
            }
        }

        PasswordPolicy policy;
        try {
            policy = new PasswordPolicy(
                    range(c, "passwords.min-length", 8, 1, 128),
                    range(c, "passwords.max-length", 64, 1, 128),
                    c.getBoolean("passwords.require-lowercase", true),
                    c.getBoolean("passwords.require-uppercase", false),
                    c.getBoolean("passwords.require-digit", true),
                    c.getBoolean("passwords.require-symbol", false),
                    c.getBoolean("passwords.deny-username", true),
                    c.getBoolean("passwords.deny-common", true));
        } catch (IllegalArgumentException e) {
            throw new IllegalArgumentException("passwords: " + e.getMessage());
        }

        Argon2Params argon2;
        try {
            argon2 = new Argon2Params(
                    c.getInt("passwords.argon2.memory-kib", Argon2Params.DEFAULT.memoryKib()),
                    c.getInt("passwords.argon2.iterations", Argon2Params.DEFAULT.iterations()),
                    c.getInt("passwords.argon2.parallelism", Argon2Params.DEFAULT.parallelism()),
                    c.getInt("passwords.argon2.salt-bytes", Argon2Params.DEFAULT.saltBytes()),
                    c.getInt("passwords.argon2.hash-bytes", Argon2Params.DEFAULT.hashBytes()));
        } catch (IllegalArgumentException e) {
            throw new IllegalArgumentException("passwords.argon2: " + e.getMessage());
        }

        AttemptTracker.Config attempts;
        try {
            attempts = new AttemptTracker.Config(
                    range(c, "security.max-attempts", 5, 1, 100),
                    range(c, "security.attempt-window-seconds", 300, 1, 86_400) * 1000L,
                    range(c, "security.lockout-seconds", 300, 1, 86_400) * 1000L,
                    range(c, "security.attempt-cooldown-millis", 1500, 0, 60_000),
                    range(c, "security.ip-max-attempts", 15, 1, 1000),
                    range(c, "security.ip-lockout-seconds", 900, 1, 86_400) * 1000L);
        } catch (IllegalArgumentException e) {
            throw new IllegalArgumentException("security: " + e.getMessage());
        }

        return new Settings(
                dbFile,
                range(c, "authentication.timeout-seconds", 60, 10, 600),
                range(c, "authentication.reminder-interval-seconds", 10, 1, 120),
                pattern,
                c.getBoolean("authentication.deny-duplicate-login", true),
                Set.copyOf(allowed),
                c.getBoolean("authentication.hide-chat-from-unauthenticated", true),
                c.getBoolean("authentication.allow-plugin-teleports", true),
                policy,
                argon2,
                attempts,
                range(c, "security.max-accounts-per-ip", 3, 0, 1000),
                c.getBoolean("security.kick-on-lockout", true),
                c.getBoolean("security.hide-passwords-in-logs", true),
                c.getBoolean("sessions.enabled", true),
                range(c, "sessions.duration-minutes", 30, 1, 10_080) * 60_000L,
                c.getBoolean("sessions.bind-to-ip", true),
                range(c, "statistics.retention-days", 30, 1, 3650));
    }

    private static int range(FileConfiguration c, String path, int def, int min, int max) {
        int value = c.getInt(path, def);
        if (value < min || value > max) {
            throw new IllegalArgumentException(path + " debe estar entre " + min + " y " + max + " (valor: " + value + ")");
        }
        return value;
    }
}
