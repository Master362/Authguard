package dev.authguard.storage;

import java.util.UUID;

/** Cuenta registrada. Las marcas de tiempo son milisegundos desde epoch (0 = nunca). */
public record Account(UUID uuid, String username, String passwordHash, boolean mustChange, long registeredAt,
                      String registerIp, long lastLoginAt, String lastLoginIp, long passwordChangedAt) {
}
