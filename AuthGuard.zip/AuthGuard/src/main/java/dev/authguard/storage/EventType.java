package dev.authguard.storage;

/** Tipos de evento de auditoría guardados en la tabla auth_events. */
public final class EventType {
    public static final String LOGIN_OK = "LOGIN_OK";
    public static final String LOGIN_FAIL = "LOGIN_FAIL";
    public static final String SESSION_LOGIN = "SESSION_LOGIN";
    public static final String LOCKOUT = "LOCKOUT";
    public static final String REGISTER = "REGISTER";
    public static final String PASSWORD_CHANGED = "PASSWORD_CHANGED";
    public static final String PASSWORD_CHANGE_FAIL = "PASSWORD_CHANGE_FAIL";
    public static final String KICK_TIMEOUT = "KICK_TIMEOUT";
    public static final String ADMIN = "ADMIN";

    private EventType() {
    }
}
