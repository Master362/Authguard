package dev.authguard.storage;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;

/** Operaciones sobre cuentas y auditoría. Todas las consultas son parametrizadas y asíncronas. */
public final class AccountRepository {

    public record IpCount(String ip, long count) { }

    static final String SQL_CREATE_ACCOUNTS = "CREATE TABLE IF NOT EXISTS accounts (uuid TEXT PRIMARY KEY, username TEXT NOT NULL, username_lower TEXT NOT NULL UNIQUE, password_hash TEXT NOT NULL, must_change INTEGER NOT NULL DEFAULT 0, registered_at INTEGER NOT NULL, register_ip TEXT, last_login_at INTEGER NOT NULL DEFAULT 0, last_login_ip TEXT, password_changed_at INTEGER NOT NULL DEFAULT 0)";
    static final String SQL_CREATE_EVENTS = "CREATE TABLE IF NOT EXISTS auth_events (id INTEGER PRIMARY KEY AUTOINCREMENT, ts INTEGER NOT NULL, type TEXT NOT NULL, username TEXT, ip TEXT)";
    static final String SQL_IDX_EVENTS = "CREATE INDEX IF NOT EXISTS idx_events_ts ON auth_events (ts, type)";
    static final String SQL_IDX_REGIP = "CREATE INDEX IF NOT EXISTS idx_accounts_regip ON accounts (register_ip)";
    static final String SQL_FIND_UUID = "SELECT * FROM accounts WHERE uuid = ?";
    static final String SQL_FIND_NAME = "SELECT * FROM accounts WHERE username_lower = ?";
    static final String SQL_INSERT = "INSERT OR IGNORE INTO accounts (uuid, username, username_lower, password_hash, must_change, registered_at, register_ip, last_login_at, last_login_ip, password_changed_at) VALUES (?,?,?,?,?,?,?,?,?,?)";
    static final String SQL_UPDATE_PASSWORD = "UPDATE accounts SET password_hash = ?, must_change = ?, password_changed_at = ? WHERE uuid = ?";
    static final String SQL_UPDATE_HASH = "UPDATE accounts SET password_hash = ? WHERE uuid = ?";
    static final String SQL_UPDATE_LOGIN = "UPDATE accounts SET last_login_at = ?, last_login_ip = ? WHERE uuid = ?";
    static final String SQL_DELETE = "DELETE FROM accounts WHERE uuid = ?";
    static final String SQL_COUNT_REGIP = "SELECT COUNT(*) FROM accounts WHERE register_ip = ?";
    static final String SQL_COUNT_ACCOUNTS = "SELECT COUNT(*) FROM accounts";
    static final String SQL_INSERT_EVENT = "INSERT INTO auth_events (ts, type, username, ip) VALUES (?,?,?,?)";
    static final String SQL_EVENTS_SINCE = "SELECT type, COUNT(*) FROM auth_events WHERE ts >= ? GROUP BY type ORDER BY type";
    static final String SQL_TOP_IPS = "SELECT ip, COUNT(*) AS c FROM auth_events WHERE ts >= ? AND type = 'LOGIN_FAIL' AND ip IS NOT NULL GROUP BY ip ORDER BY c DESC LIMIT ?";
    static final String SQL_PURGE_EVENTS = "DELETE FROM auth_events WHERE ts < ?";

    private final Database db;

    public AccountRepository(Database db) {
        this.db = db;
    }

    public CompletableFuture<Void> initSchema() {
        return db.submit(c -> {
            try (Statement st = c.createStatement()) {
                st.execute(SQL_CREATE_ACCOUNTS);
                st.execute(SQL_CREATE_EVENTS);
                st.execute(SQL_IDX_EVENTS);
                st.execute(SQL_IDX_REGIP);
            }
            return null;
        });
    }

    public CompletableFuture<Optional<Account>> findByUuid(UUID uuid) {
        return db.submit(c -> {
            try (PreparedStatement ps = c.prepareStatement(SQL_FIND_UUID)) {
                ps.setString(1, uuid.toString());
                return readOne(ps);
            }
        });
    }

    /** Busca por nombre en minúsculas (username_lower). */
    public CompletableFuture<Optional<Account>> findByName(String lowerName) {
        return db.submit(c -> {
            try (PreparedStatement ps = c.prepareStatement(SQL_FIND_NAME)) {
                ps.setString(1, lowerName);
                return readOne(ps);
            }
        });
    }

    private static Optional<Account> readOne(PreparedStatement ps) throws SQLException {
        try (ResultSet rs = ps.executeQuery()) {
            if (rs.next()) {
                return Optional.of(map(rs));
            }
            return Optional.empty();
        }
    }

    private static Account map(ResultSet rs) throws SQLException {
        return new Account(
                UUID.fromString(rs.getString("uuid")),
                rs.getString("username"),
                rs.getString("password_hash"),
                rs.getInt("must_change") != 0,
                rs.getLong("registered_at"),
                rs.getString("register_ip"),
                rs.getLong("last_login_at"),
                rs.getString("last_login_ip"),
                rs.getLong("password_changed_at"));
    }

    /** Inserta la cuenta. Devuelve false si ya existía el UUID o el nombre. */
    public CompletableFuture<Boolean> insert(Account a) {
        return db.submit(c -> {
            try (PreparedStatement ps = c.prepareStatement(SQL_INSERT)) {
                ps.setString(1, a.uuid().toString());
                ps.setString(2, a.username());
                ps.setString(3, a.username().toLowerCase(java.util.Locale.ROOT));
                ps.setString(4, a.passwordHash());
                ps.setInt(5, a.mustChange() ? 1 : 0);
                ps.setLong(6, a.registeredAt());
                ps.setString(7, a.registerIp());
                ps.setLong(8, a.lastLoginAt());
                ps.setString(9, a.lastLoginIp());
                ps.setLong(10, a.passwordChangedAt());
                return ps.executeUpdate() == 1;
            }
        });
    }

    public CompletableFuture<Boolean> updatePassword(UUID uuid, String hash, boolean mustChange, long now) {
        return db.submit(c -> {
            try (PreparedStatement ps = c.prepareStatement(SQL_UPDATE_PASSWORD)) {
                ps.setString(1, hash);
                ps.setInt(2, mustChange ? 1 : 0);
                ps.setLong(3, now);
                ps.setString(4, uuid.toString());
                return ps.executeUpdate() == 1;
            }
        });
    }

    /** Actualiza solo el hash (re-hash transparente por cambio de parámetros). */
    public CompletableFuture<Boolean> updateHash(UUID uuid, String hash) {
        return db.submit(c -> {
            try (PreparedStatement ps = c.prepareStatement(SQL_UPDATE_HASH)) {
                ps.setString(1, hash);
                ps.setString(2, uuid.toString());
                return ps.executeUpdate() == 1;
            }
        });
    }

    public CompletableFuture<Boolean> updateLogin(UUID uuid, String ip, long now) {
        return db.submit(c -> {
            try (PreparedStatement ps = c.prepareStatement(SQL_UPDATE_LOGIN)) {
                ps.setLong(1, now);
                ps.setString(2, ip);
                ps.setString(3, uuid.toString());
                return ps.executeUpdate() == 1;
            }
        });
    }

    public CompletableFuture<Boolean> delete(UUID uuid) {
        return db.submit(c -> {
            try (PreparedStatement ps = c.prepareStatement(SQL_DELETE)) {
                ps.setString(1, uuid.toString());
                return ps.executeUpdate() == 1;
            }
        });
    }

    public CompletableFuture<Integer> countByRegisterIp(String ip) {
        return db.submit(c -> {
            try (PreparedStatement ps = c.prepareStatement(SQL_COUNT_REGIP)) {
                ps.setString(1, ip);
                try (ResultSet rs = ps.executeQuery()) {
                    return rs.next() ? rs.getInt(1) : 0;
                }
            }
        });
    }

    public CompletableFuture<Long> countAccounts() {
        return db.submit(c -> {
            try (PreparedStatement ps = c.prepareStatement(SQL_COUNT_ACCOUNTS);
                 ResultSet rs = ps.executeQuery()) {
                return rs.next() ? rs.getLong(1) : 0L;
            }
        });
    }

    public CompletableFuture<Void> logEvent(String type, String username, String ip, long ts) {
        return db.submit(c -> {
            try (PreparedStatement ps = c.prepareStatement(SQL_INSERT_EVENT)) {
                ps.setLong(1, ts);
                ps.setString(2, type);
                ps.setString(3, username);
                ps.setString(4, ip);
                ps.executeUpdate();
            }
            return null;
        });
    }

    public CompletableFuture<Map<String, Long>> countEventsSince(long since) {
        return db.submit(c -> {
            Map<String, Long> result = new LinkedHashMap<>();
            try (PreparedStatement ps = c.prepareStatement(SQL_EVENTS_SINCE)) {
                ps.setLong(1, since);
                try (ResultSet rs = ps.executeQuery()) {
                    while (rs.next()) {
                        result.put(rs.getString(1), rs.getLong(2));
                    }
                }
            }
            return result;
        });
    }

    public CompletableFuture<List<IpCount>> topFailingIps(long since, int limit) {
        return db.submit(c -> {
            List<IpCount> result = new ArrayList<>();
            try (PreparedStatement ps = c.prepareStatement(SQL_TOP_IPS)) {
                ps.setLong(1, since);
                ps.setInt(2, limit);
                try (ResultSet rs = ps.executeQuery()) {
                    while (rs.next()) {
                        result.add(new IpCount(rs.getString(1), rs.getLong(2)));
                    }
                }
            }
            return result;
        });
    }

    public CompletableFuture<Integer> purgeEventsBefore(long ts) {
        return db.submit(c -> {
            try (PreparedStatement ps = c.prepareStatement(SQL_PURGE_EVENTS)) {
                ps.setLong(1, ts);
                return ps.executeUpdate();
            }
        });
    }
}
