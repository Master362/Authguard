package dev.authguard.storage;

import java.nio.file.Path;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.CompletionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.RejectedExecutionException;
import java.util.concurrent.TimeUnit;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Acceso a SQLite. Mantiene UNA conexión y ejecuta todo en un único hilo dedicado,
 * de modo que el hilo principal del servidor nunca toca la base de datos.
 */
public final class Database implements AutoCloseable {

    @FunctionalInterface
    public interface SqlFunction<T> {
        T apply(Connection connection) throws SQLException;
    }

    private final Logger logger;
    private final ExecutorService executor;
    private final Connection connection;

    public Database(Path file, Logger logger) throws SQLException, ClassNotFoundException {
        this.logger = logger;
        Class.forName("org.sqlite.JDBC");
        this.connection = DriverManager.getConnection("jdbc:sqlite:" + file.toAbsolutePath());
        try (Statement st = connection.createStatement()) {
            st.execute("PRAGMA journal_mode=WAL");
            st.execute("PRAGMA synchronous=NORMAL");
            st.execute("PRAGMA busy_timeout=5000");
        }
        this.executor = Executors.newSingleThreadExecutor(r -> {
            Thread t = new Thread(r, "AuthGuard-DB");
            t.setDaemon(true);
            return t;
        });
    }

    /** Ejecuta la operación en el hilo de base de datos. */
    public <T> CompletableFuture<T> submit(SqlFunction<T> function) {
        try {
            return CompletableFuture.supplyAsync(() -> {
                try {
                    return function.apply(connection);
                } catch (SQLException e) {
                    throw new CompletionException(e);
                }
            }, executor);
        } catch (RejectedExecutionException e) {
            return CompletableFuture.failedFuture(e);
        }
    }

    @Override
    public void close() {
        executor.shutdown();
        try {
            if (!executor.awaitTermination(10, TimeUnit.SECONDS)) {
                logger.warning("La base de datos tardó demasiado en vaciar su cola de operaciones.");
                executor.shutdownNow();
            }
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            executor.shutdownNow();
        }
        try {
            connection.close();
        } catch (SQLException e) {
            logger.log(Level.WARNING, "Error al cerrar la base de datos", e);
        }
    }
}
