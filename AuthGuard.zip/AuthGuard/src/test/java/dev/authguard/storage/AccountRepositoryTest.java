package dev.authguard.storage;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.nio.file.Path;
import java.util.UUID;
import java.util.logging.Logger;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

class AccountRepositoryTest {

    @TempDir
    Path dir;

    private Database db;
    private AccountRepository repo;

    @BeforeEach
    void setUp() throws Exception {
        db = new Database(dir.resolve("test.db"), Logger.getAnonymousLogger());
        repo = new AccountRepository(db);
        repo.initSchema().join();
    }

    @AfterEach
    void tearDown() {
        db.close();
    }

    private static Account account(UUID id, String name) {
        return new Account(id, name, "hash", false, 1L, "1.1.1.1", 1L, "1.1.1.1", 1L);
    }

    @Test
    void insertFindAndUniqueness() {
        UUID id = UUID.randomUUID();
        assertTrue(repo.insert(account(id, "Steve")).join());
        assertFalse(repo.insert(account(id, "Otro")).join());
        assertFalse(repo.insert(account(UUID.randomUUID(), "sTeVe")).join());
        assertEquals("Steve", repo.findByName("steve").join().orElseThrow().username());
        assertEquals(id, repo.findByUuid(id).join().orElseThrow().uuid());
    }

    @Test
    void sqlInjectionIsStoredLiterally() {
        UUID id = UUID.randomUUID();
        String evil = "x' OR '1'='1";
        assertTrue(repo.insert(account(id, evil)).join());
        assertEquals(id, repo.findByName(evil.toLowerCase()).join().orElseThrow().uuid());
        assertTrue(repo.findByName("x").join().isEmpty());
    }

    @Test
    void updatesAndDeletes() {
        UUID id = UUID.randomUUID();
        repo.insert(account(id, "Alex")).join();
        assertTrue(repo.updatePassword(id, "nuevo", true, 5L).join());
        Account a = repo.findByUuid(id).join().orElseThrow();
        assertEquals("nuevo", a.passwordHash());
        assertTrue(a.mustChange());
        assertEquals(1, (int) repo.countByRegisterIp("1.1.1.1").join());
        assertTrue(repo.delete(id).join());
        assertTrue(repo.findByUuid(id).join().isEmpty());
    }

    @Test
    void eventsAndStats() {
        repo.logEvent(EventType.LOGIN_FAIL, "a", "9.9.9.9", 100L).join();
        repo.logEvent(EventType.LOGIN_FAIL, "b", "9.9.9.9", 100L).join();
        repo.logEvent(EventType.LOGIN_OK, "c", "1.1.1.1", 100L).join();
        assertEquals(2L, (long) repo.countEventsSince(0).join().get(EventType.LOGIN_FAIL));
        assertEquals("9.9.9.9", repo.topFailingIps(0, 5).join().get(0).ip());
        assertEquals(3, (int) repo.purgeEventsBefore(200L).join());
    }
}
