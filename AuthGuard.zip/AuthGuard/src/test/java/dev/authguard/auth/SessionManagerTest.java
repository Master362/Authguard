package dev.authguard.auth;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.UUID;
import java.util.concurrent.atomic.AtomicLong;

import org.junit.jupiter.api.Test;

class SessionManagerTest {

    private final AtomicLong now = new AtomicLong(0);
    private final SessionManager sessions = new SessionManager(now::get);
    private final UUID id = UUID.randomUUID();

    @Test
    void sameIpConsumesOnce() {
        sessions.create(id, "1.2.3.4", 10_000);
        assertTrue(sessions.consume(id, "1.2.3.4", true));
        assertFalse(sessions.consume(id, "1.2.3.4", true));
    }

    @Test
    void foreignIpIsRejectedWithoutDestroyingSession() {
        sessions.create(id, "1.2.3.4", 10_000);
        assertFalse(sessions.consume(id, "9.9.9.9", true));
        assertEquals(1, sessions.size());
        assertTrue(sessions.consume(id, "1.2.3.4", true));
    }

    @Test
    void expiresAndCanBeInvalidated() {
        sessions.create(id, "1.2.3.4", 10_000);
        now.set(10_000);
        assertFalse(sessions.consume(id, "1.2.3.4", true));
        sessions.create(id, "x", 1_000);
        sessions.invalidate(id);
        assertEquals(0, sessions.size());
    }
}
