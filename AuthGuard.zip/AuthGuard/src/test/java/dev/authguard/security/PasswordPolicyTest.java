package dev.authguard.security;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.Test;

class PasswordPolicyTest {

    private final PasswordPolicy policy = new PasswordPolicy(8, 64, true, false, true, false, true, true);

    @Test
    void acceptsValidPassword() {
        assertTrue(policy.validate("Abcdef12", "Steve").isEmpty());
    }

    @Test
    void rejectsWeakPasswords() {
        assertTrue(policy.validate("abc1", "Steve").contains(PasswordPolicy.Violation.TOO_SHORT));
        assertTrue(policy.validate("abcdefgh", "Steve").contains(PasswordPolicy.Violation.NEEDS_DIGIT));
        assertTrue(policy.validate("12345678", "Steve").contains(PasswordPolicy.Violation.TOO_COMMON));
        assertTrue(policy.validate("xxSTEVEx1", "Steve").contains(PasswordPolicy.Violation.CONTAINS_USERNAME));
        assertTrue(policy.validate("a".repeat(70) + "1", "Steve").contains(PasswordPolicy.Violation.TOO_LONG));
        assertFalse(policy.validate("abcdef1\u0007x", "Steve").isEmpty());
    }

    @Test
    void rejectsInvalidPolicy() {
        assertThrows(IllegalArgumentException.class,
                () -> new PasswordPolicy(10, 5, true, true, true, true, true, true));
    }
}
