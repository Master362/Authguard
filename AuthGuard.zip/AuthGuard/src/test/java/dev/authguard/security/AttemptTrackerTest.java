package dev.authguard.security;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.concurrent.atomic.AtomicLong;

import org.junit.jupiter.api.Test;

class AttemptTrackerTest {

    private final AtomicLong now = new AtomicLong(1_000_000);
    private final AttemptTracker.Config config = new AttemptTracker.Config(3, 60_000, 30_000, 1_000, 5, 120_000);
    private final AttemptTracker tracker = new AttemptTracker(config, now::get);

    @Test
    void cooldownBetweenAttempts() {
        assertTrue(tracker.tryAcquire("a", "1.1.1.1").allowed());
        assertEquals(AttemptTracker.Status.COOLDOWN, tracker.tryAcquire("a", "1.1.1.1").status());
        now.addAndGet(1_500);
        assertTrue(tracker.tryAcquire("a", "1.1.1.1").allowed());
    }

    @Test
    void locksAfterMaxFailuresAndExpires() {
        tracker.recordFailure("a", "1.1.1.1");
        tracker.recordFailure("a", "1.1.1.1");
        assertTrue(tracker.recordFailure("a", "1.1.1.1").lockedNow());
        AttemptTracker.Decision d = tracker.tryAcquire("a", "2.2.2.2");
        assertEquals(AttemptTracker.Status.LOCKED, d.status());
        assertEquals(30_000, d.waitMillis());
        now.addAndGet(30_001);
        assertTrue(tracker.tryAcquire("a", "2.2.2.2").allowed());
    }

    @Test
    void successResetsFailures() {
        tracker.recordFailure("a", "1.1.1.1");
        tracker.recordFailure("a", "1.1.1.1");
        tracker.recordSuccess("a");
        assertFalse(tracker.recordFailure("a", "1.1.1.1").lockedNow());
    }

    @Test
    void ipLockSpansAccountsAndCanBeUnlocked() {
        boolean locked = false;
        for (int i = 0; i < 5; i++) {
            locked = tracker.recordFailure("acc" + i, "6.6.6.6").lockedNow();
        }
        assertTrue(locked);
        assertTrue(tracker.ipLockRemaining("6.6.6.6") > 0);
        assertEquals(AttemptTracker.Status.LOCKED, tracker.tryAcquire("other", "6.6.6.6").status());
        assertTrue(tracker.unlock("6.6.6.6"));
        assertEquals(0, tracker.ipLockRemaining("6.6.6.6"));
    }

    @Test
    void oldFailuresOutsideWindowDoNotAccumulate() {
        tracker.recordFailure("w", "7.7.7.7");
        tracker.recordFailure("w", "7.7.7.7");
        now.addAndGet(61_000);
        assertFalse(tracker.recordFailure("w", "7.7.7.7").lockedNow());
    }
}
