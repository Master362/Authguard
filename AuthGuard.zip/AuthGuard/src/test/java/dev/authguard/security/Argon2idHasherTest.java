package dev.authguard.security;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.Test;

class Argon2idHasherTest {

    // Parámetros mínimos permitidos para que la prueba sea rápida.
    private final Argon2idHasher hasher = new Argon2idHasher(new Argon2Params(8192, 1, 1, 16, 32));

    @Test
    void hashesAndVerifies() {
        String hash = hasher.hash("Contraseña-Segura1");
        assertTrue(hash.startsWith("$argon2id$v=19$m=8192,t=1,p=1$"));
        assertFalse(hash.contains("Contraseña"));
        assertTrue(hasher.verify("Contraseña-Segura1", hash));
        assertFalse(hasher.verify("contraseña-segura1", hash));
    }

    @Test
    void usesRandomSalt() {
        assertNotEquals(hasher.hash("misma-clave1"), hasher.hash("misma-clave1"));
    }

    @Test
    void rejectsMalformedAndOversizedHashes() {
        assertFalse(hasher.verify("x", null));
        assertFalse(hasher.verify("x", "texto-plano"));
        assertFalse(hasher.verify("x", "$argon2id$v=19$m=99999999,t=1,p=1$AAAAAAAAAAAAAAAAAAAAAA$AAAAAAAAAAAAAAAAAAAAAA"));
        assertFalse(hasher.verify("x", "$argon2i$v=19$m=8192,t=1,p=1$AAAAAAAAAAAAAAAAAAAAAA$AAAAAAAAAAAAAAAAAAAAAA"));
    }

    @Test
    void detectsOutdatedParameters() {
        String hash = hasher.hash("clave-de-prueba1");
        assertFalse(hasher.needsRehash(hash));
        hasher.configure(new Argon2Params(16384, 2, 1, 16, 32));
        assertTrue(hasher.needsRehash(hash));
        assertTrue(hasher.needsRehash("basura"));
    }
}
